DROP TABLE IF EXISTS `pet`;
CREATE TABLE `pet` (
  `pet_id` varchar(64) NOT NULL COMMENT '宠物ID',
  `user_id` bigint(20) DEFAULT NULL COMMENT '绑定用户ID（主从关联）',
  `name` varchar(50) NOT NULL COMMENT '宠物昵称',
  `avatar` varchar(255) DEFAULT '' COMMENT '宠物头像',
  `type` varchar(20) DEFAULT '猫' COMMENT '种类 (如: 猫, 狗, 异宠)',
  `breed` varchar(50) DEFAULT '' COMMENT '品种 (如: 英短, 秋田)',
  `gender` char(1) DEFAULT '0' COMMENT '性别 (0公 1母 2未知)',
  `birthday` date DEFAULT NULL COMMENT '生日',
  `weight` decimal(5,2) DEFAULT '0.00' COMMENT '体重(kg)',
  `health_status` varchar(50) DEFAULT '健康' COMMENT '健康状态',
  `owner_name` varchar(100) DEFAULT NULL COMMENT '主人姓名',
  `phone` varchar(20) DEFAULT NULL COMMENT '联系电话',
  `treatment_status` varchar(50) DEFAULT '观察中' COMMENT '当前治疗状态',
  `last_visit_time` datetime DEFAULT NULL COMMENT '最后就诊时间',
  `create_by` varchar(64) DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`pet_id`) USING BTREE,
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='宠物档案表';

-- 插入一条初始数据用于测试
INSERT INTO `pet` VALUES ('P10001', 1, '雪球', '/profile/avatar/default_cat.png', '猫', '布偶猫', '1', '2022-05-10', 4.50, '健康', '小王', '15520187167', '观察中', '2026-04-03 11:45:05', 'admin', sysdate(), '', null, '温顺懂事');
INSERT INTO `pet` VALUES ('P10002', 1, '旺财', '/profile/avatar/default_dog.png', '狗', '金毛寻回犬', '0', '2021-08-15', 25.00, '健康', '张三', '15520187167', '已康复', '2026-04-02 14:48:05', 'admin', sysdate(), '', null, '活泼好动');
