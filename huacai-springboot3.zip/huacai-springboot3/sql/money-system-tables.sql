USE `pet-hospital`;

DROP TABLE IF EXISTS `sys_member`;
CREATE TABLE `sys_member` (
  `member_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '会员主键ID',
  `user_id` bigint(20) NOT NULL COMMENT '系统用户ID',
  `level` varchar(20) DEFAULT '0' COMMENT '会员等级(0普通 1白银 2黄金 3钻石)',
  `balance` decimal(10,2) DEFAULT '0.00' COMMENT '账户余额',
  `points` bigint(20) DEFAULT '0' COMMENT '可用积分',
  `total_points` bigint(20) DEFAULT '0' COMMENT '累计获得总积分',
  `create_by` varchar(64) DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`member_id`),
  UNIQUE KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='会员资产表';

DROP TABLE IF EXISTS `transaction_record`;
CREATE TABLE `transaction_record` (
  `id` varchar(64) NOT NULL COMMENT '交易主键',
  `user_id` bigint(20) NOT NULL COMMENT '用户ID',
  `type` varchar(20) NOT NULL COMMENT '交易类型: RECHARGE 充值, CONSUME 消费',
  `amount` decimal(10,2) NOT NULL COMMENT '交易金额',
  `payment_method` varchar(20) DEFAULT '' COMMENT '支付方式: ALIPAY, WECHAT, BANKCARD, UNIONPAY, BALANCE',
  `points_earned` bigint(20) DEFAULT '0' COMMENT '获得积分',
  `create_time` datetime DEFAULT NULL COMMENT '交易时间',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注(订单号等)',
  PRIMARY KEY (`id`),
  KEY `idx_trans_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='消费充值流水表';

DROP TABLE IF EXISTS `coupon`;
CREATE TABLE `coupon` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '优惠券主键',
  `name` varchar(100) NOT NULL COMMENT '券名',
  `type` varchar(20) NOT NULL COMMENT '类型(DISCOUNT 折扣券, FULL_REDUCTION 满减券, CASH 现金抵扣券)',
  `value` decimal(10,2) NOT NULL COMMENT '面值/折扣率',
  `min_amount` decimal(10,2) DEFAULT '0.00' COMMENT '起用金额门槛',
  `total_limit` int(11) DEFAULT '-1' COMMENT '发行总量(-1不限)',
  `used_count` int(11) DEFAULT '0' COMMENT '已使用/被领取量',
  `expire_time` datetime DEFAULT NULL COMMENT '过期时间',
  `create_by` varchar(64) DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='优惠券表';

DROP TABLE IF EXISTS `user_coupon`;
CREATE TABLE `user_coupon` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '领券流水主键',
  `user_id` bigint(20) NOT NULL COMMENT '用户ID',
  `coupon_id` bigint(20) NOT NULL COMMENT '优惠券ID',
  `status` char(1) DEFAULT '0' COMMENT '状态(0未使用 1已使用 2已过期)',
  `used_time` datetime DEFAULT NULL COMMENT '使用时间',
  `create_time` datetime DEFAULT NULL COMMENT '领取时间',
  PRIMARY KEY (`id`),
  KEY `idx_uc_user` (`user_id`),
  KEY `idx_uc_coupon` (`coupon_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户领券记录表';

-- 初始化一条模拟系统用的优惠券
INSERT INTO `coupon` (`name`, `type`, `value`, `min_amount`, `total_limit`, `expire_time`, `create_time`) 
VALUES ('新人通用满百减十卷', 'FULL_REDUCTION', 10.00, 100.00, 1000, '2027-12-31 23:59:59', sysdate());
