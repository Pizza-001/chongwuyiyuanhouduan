USE `pet-hospital`;

ALTER TABLE pet ADD COLUMN owner_name VARCHAR(100) COMMENT '主人姓名';
ALTER TABLE pet ADD COLUMN phone VARCHAR(20) COMMENT '联系电话';
ALTER TABLE pet ADD COLUMN treatment_status VARCHAR(50) COMMENT '当前治疗状态';
ALTER TABLE pet ADD COLUMN last_visit_time DATETIME COMMENT '最后就诊时间';
