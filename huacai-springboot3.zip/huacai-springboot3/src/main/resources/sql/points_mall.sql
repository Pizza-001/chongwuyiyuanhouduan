-- 积分商城商品表
CREATE TABLE IF NOT EXISTS `hospital_points_mall` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `target_id` bigint(20) NOT NULL COMMENT '目标ID (药品ID或优惠券ID)',
  `type` varchar(20) NOT NULL COMMENT '类型 (MEDICINE/COUPON)',
  `points_price` bigint(20) NOT NULL COMMENT '所需积分',
  `stock` int(11) DEFAULT '99' COMMENT '剩余库存',
  `status` char(1) DEFAULT '0' COMMENT '状态 (0正常 1停用)',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `create_by` varchar(64) DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='积分商城商品表';

-- 积分兑换记录表
CREATE TABLE IF NOT EXISTS `hospital_points_exchange_record` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '记录ID',
  `user_id` bigint(20) NOT NULL COMMENT '用户ID',
  `product_id` bigint(20) NOT NULL COMMENT '商品ID (关联hospital_points_mall)',
  `exchange_points` bigint(20) NOT NULL COMMENT '消耗积分',
  `exchange_time` datetime DEFAULT NULL COMMENT '兑换时间',
  `status` char(1) DEFAULT '0' COMMENT '状态 (0已兑换 1已完成/已发放 2已取消)',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='积分兑换记录表';

-- 初始填充数据 (将所有药品和优惠券加入商城)
-- 清理旧演示数据防止重复
TRUNCATE TABLE `hospital_points_mall`;

-- 1. 批量加入所有药品 (按价格换算积分，比如 1元=1积分，最低50)
INSERT INTO `hospital_points_mall` (target_id, type, points_price, stock, remark, create_time)
SELECT 
    medicine_id, 
    'MEDICINE', 
    GREATEST(CAST(price AS SIGNED), 50), -- 积分等于价格，最低50分
    100, 
    CONCAT(name, ' 积分兑换'), 
    NOW() 
FROM hospital_medicine 
WHERE status = '0';

-- 2. 批量加入所有优惠券 (按面额换算，比如 20倍面额)
INSERT INTO `hospital_points_mall` (target_id, type, points_price, stock, remark, create_time)
SELECT 
    coupon_id, 
    'COUPON', 
    CAST(amount * 20 AS SIGNED), -- 5元券100分，10元券200分
    999, 
    CONCAT(title, ' 积分兑换'), 
    NOW() 
FROM sys_coupon 
WHERE status = '0';
