-- ----------------------------
-- 1、收银结算表
-- ----------------------------
CREATE TABLE IF NOT EXISTS `hospital_billing` (
    `id` varchar(64) NOT NULL COMMENT 'ID',
    `order_no` varchar(64) NOT NULL COMMENT '订单流水号',
    `pet_id` varchar(64) DEFAULT NULL COMMENT '宠物ID',
    `member_id` varchar(64) DEFAULT NULL COMMENT '会员/用户ID',
    `business_type` varchar(20) DEFAULT NULL COMMENT '业务类型(VACCINE疫苗, CLINIC门诊, MEDICINE药品, GENERAL其他)',
    `source_id` varchar(64) DEFAULT NULL COMMENT '来源业务ID',
    `total_amount` decimal(10,2) DEFAULT '0.00' COMMENT '总金额',
    `discount_amount` decimal(10,2) DEFAULT '0.00' COMMENT '优惠金额',
    `pay_amount` decimal(10,2) DEFAULT '0.00' COMMENT '实付金额',
    `status` char(1) DEFAULT '0' COMMENT '支付状态(0待结算, 1已结算, 2已取消)',
    `payment_method` varchar(20) DEFAULT NULL COMMENT '支付方式(CASH, WECHAT, ALIPAY, BALANCE)',
    `remark` varchar(500) DEFAULT NULL COMMENT '备注',
    `payment_time` datetime DEFAULT NULL COMMENT '支付时间',
    `create_by` varchar(64) DEFAULT '' COMMENT '创建者',
    `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_by` varchar(64) DEFAULT '' COMMENT '更新者',
    `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_order_no` (`order_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='收银结算记录表';

-- ----------------------------
-- 2、插入测试数据
-- ----------------------------
INSERT INTO `hospital_billing` (id, order_no, pet_id, member_id, business_type, total_amount, pay_amount, status, create_time)
VALUES ('1', 'BILL20260423001', '1', '1', 'CLINIC', 280.00, 280.00, '0', NOW());

INSERT INTO `hospital_billing` (id, order_no, pet_id, member_id, business_type, total_amount, pay_amount, status, create_time)
VALUES ('2', 'BILL20260423002', '1', '1', 'VACCINE', 150.00, 150.00, '1', NOW());
