-- 会员成长值流水表
DROP TABLE IF EXISTS `sys_growth_record`;
CREATE TABLE `sys_growth_record` (
    `id`             bigint(20)      NOT NULL AUTO_INCREMENT    COMMENT '记录ID',
    `user_id`        bigint(20)      NOT NULL                   COMMENT '用户ID',
    `type`           varchar(20)     NOT NULL                   COMMENT '变动类型 (CONSUMPTION, TASK, ADJUSTMENT)',
    `change_amount`  bigint(20)      NOT NULL                   COMMENT '变动值',
    `current_growth` bigint(20)      DEFAULT '0'                COMMENT '变动后成长值',
    `remark`         varchar(500)    DEFAULT NULL               COMMENT '备注',
    `create_time`    datetime        DEFAULT NULL               COMMENT '创建时间',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='会员成长值流水表';
