-- 会员资产及流水初始化脚本
-- 请在数据库管理工具中执行以下 SQL

-- 1. 会员信息表
DROP TABLE IF EXISTS `sys_member`;
CREATE TABLE `sys_member` (
    `member_id`    bigint(20)      NOT NULL AUTO_INCREMENT    COMMENT '会员ID',
    `user_id`      bigint(20)      NOT NULL                   COMMENT '关联用户ID',
    `level`        char(1)         DEFAULT '0'               COMMENT '会员等级 (0青铜 1白银 2黄金 3铂金 4钻石)',
    `balance`      decimal(10,2)   DEFAULT '0.00'            COMMENT '账户余额',
    `growth_value` bigint(20)      DEFAULT '0'               COMMENT '成长值 (1元=10点)',
    `points`       bigint(20)      DEFAULT '0'               COMMENT '当前可用积分',
    `total_points` bigint(20)      DEFAULT '0'               COMMENT '累计总积分',
    `create_by`    varchar(64)     DEFAULT ''                COMMENT '创建者',
    `create_time`  datetime        DEFAULT NULL              COMMENT '创建时间',
    `update_by`    varchar(64)     DEFAULT ''                COMMENT '更新者',
    `update_time`  datetime        DEFAULT NULL              COMMENT '更新时间',
    `remark`       varchar(500)    DEFAULT NULL              COMMENT '备注',
    PRIMARY KEY (`member_id`),
    UNIQUE KEY `uk_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='会员资产表';

-- 2. 交易流水记录表
DROP TABLE IF EXISTS `transaction_record`;
CREATE TABLE `transaction_record` (
    `id`             varchar(64)     NOT NULL                  COMMENT '交易ID',
    `user_id`        bigint(20)      NOT NULL                   COMMENT '用户ID',
    `type`           varchar(20)     NOT NULL                   COMMENT '交易类型 (RECHARGE, CONSUME)',
    `amount`         decimal(10,2)   NOT NULL                   COMMENT '交易金额',
    `payment_method` varchar(20)     DEFAULT NULL               COMMENT '支付方式',
    `points_earned`  bigint(20)      DEFAULT '0'               COMMENT '产生积分',
    `create_by`      varchar(64)     DEFAULT ''                COMMENT '创建者',
    `create_time`    datetime        DEFAULT NULL              COMMENT '交易时间',
    `update_by`      varchar(64)     DEFAULT ''                COMMENT '更新者',
    `update_time`    datetime        DEFAULT NULL              COMMENT '更新时间',
    `remark`         varchar(500)    DEFAULT NULL              COMMENT '备注',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='交易流水记录表';
