-- 3. 药品信息库 (用于处方检索)
CREATE TABLE `hospital_medicine` (
  `medicine_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '药品ID',
  `name` varchar(100) NOT NULL COMMENT '药品名称',
  `specification` varchar(100) DEFAULT NULL COMMENT '规格',
  `unit` varchar(20) DEFAULT NULL COMMENT '单位(盒/片/瓶/板)',
  `price` decimal(10,2) DEFAULT 0.00 COMMENT '单价',
  `stock` int(11) DEFAULT 0 COMMENT '库存',
  `type` varchar(50) DEFAULT NULL COMMENT '类型(驱虫/抗生素/针剂/处方粮)',
  `status` char(1) DEFAULT '0' COMMENT '状态（0正常 1停用）',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`medicine_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='药品信息表';

-- 初始化一些截图中的演示数据
INSERT INTO `hospital_medicine` (`name`, `specification`, `unit`, `price`, `type`) VALUES 
('犬心保 (M号)', '中型犬适用', '盒', 280.00, '驱虫'),
('拜宠清 (全犬种)', '广谱驱虫', '片', 35.00, '驱虫'),
('速诺 (抗生素)', '阿莫西林克拉维酸钾', '板', 85.00, '抗生素'),
('康卫宁 (进口针剂)', '头孢维星钠', '支', 450.00, '针剂'),
('眼康 (护眼液)', '缓解疲劳', '瓶', 128.00, '护眼'),
('镁威口服液 (肠胃)', '调理肠胃', '瓶', 95.00, '肠胃'),
('维克洁齿水', '清新口气', '瓶', 115.00, '洁齿'),
('希尔思处方粮 (i/d)', '肠胃处方', '袋', 360.00, '处方粮');

-- 4. 处方项目详情表
CREATE TABLE `hospital_prescription_item` (
  `item_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '项目ID',
  `prescription_id` varchar(64) NOT NULL COMMENT '处方ID',
  `medicine_id` bigint(20) NOT NULL COMMENT '药品ID',
  `medicine_name` varchar(100) DEFAULT NULL COMMENT '药品名称',
  `quantity` int(11) DEFAULT 1 COMMENT '数量',
  `unit_price` decimal(10,2) DEFAULT 0.00 COMMENT '单价',
  `subtotal` decimal(10,2) DEFAULT 0.00 COMMENT '小计',
  PRIMARY KEY (`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='处方项目详情表';
