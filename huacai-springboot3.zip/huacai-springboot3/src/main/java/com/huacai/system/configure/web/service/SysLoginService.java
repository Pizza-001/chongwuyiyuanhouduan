package com.huacai.system.configure.web.service;

import com.huacai.system.general.constant.CacheConstants;
import com.huacai.system.general.constant.UserConstants;
import com.huacai.system.domain.SysUser;
import com.huacai.system.general.core.domain.model.LoginUser;
import com.huacai.system.general.core.redis.RedisCache;
import com.huacai.system.general.exception.ServiceException;
import com.huacai.system.general.exception.user.*;
import com.huacai.system.general.utils.DateUtils;
import com.huacai.system.general.utils.StringUtils;
import com.huacai.system.general.utils.ip.IpUtils;
import com.huacai.system.configure.security.context.AuthenticationContextHolder;
import com.huacai.system.service.ISysConfigService;
import com.huacai.system.service.ISysUserService;
import jakarta.annotation.Resource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;
import java.util.concurrent.TimeUnit;
import java.util.List;

/**
 * 登录校验方法
 *
 * @author huacai
 */
@Component
public class SysLoginService
{
    @Autowired
    private TokenService tokenService;

    @Resource
    private AuthenticationManager authenticationManager;

    @Autowired
    private RedisCache redisCache;

    @Autowired
    private ISysUserService userService;

    @Autowired
    private ISysConfigService configService;

    /**
     * 登录验证
     *
     * @param username 用户名
     * @param password 密码
     * @param code 验证码
     * @param uuid 唯一标识
     * @return 结果
     */
    public String login(String username, String password, String code, String uuid)
    {
        // 验证码校验
        validateCaptcha(username, code, uuid);
        // 登录前置校验
        loginPreCheck(username, password);
        // 用户验证
        Authentication authentication = null;
        try
        {
            UsernamePasswordAuthenticationToken authenticationToken = new UsernamePasswordAuthenticationToken(username, password);
            AuthenticationContextHolder.setContext(authenticationToken);
            // 该方法会去调用UserDetailsServiceImpl.loadUserByUsername
            authentication = authenticationManager.authenticate(authenticationToken);
        }
        catch (Exception e)
        {
            if (e instanceof BadCredentialsException)
            {
                throw new UserPasswordNotMatchException();
            }
            else
            {
                throw new ServiceException(e.getMessage());
            }
        }
        finally
        {
            AuthenticationContextHolder.clearContext();
        }
        LoginUser loginUser = (LoginUser) authentication.getPrincipal();
        recordLoginInfo(loginUser.getUserId());
        // 生成token
        return tokenService.createToken(loginUser);
    }

    /**
     * 手机验证码登录
     *
     * @param phonenumber 手机号
     * @param smsCode 验证码
     * @return 结果
     */
    public String smsLogin(String phonenumber, String smsCode)
    {
        // 1. 验证码校验
        String verifyKey = CacheConstants.SMS_CODE_KEY + phonenumber;
        String cacheCode = redisCache.getCacheObject(verifyKey);
        if (StringUtils.isEmpty(cacheCode))
        {
            throw new ServiceException("验证码已过期");
        }
        if (!smsCode.equals(cacheCode))
        {
            throw new ServiceException("验证码错误");
        }
        redisCache.deleteObject(verifyKey);

        // 2. 查找用户
        SysUser userQuery = new SysUser();
        userQuery.setPhonenumber(phonenumber);
        List<SysUser> users = userService.selectUserList(userQuery);
        if (StringUtils.isEmpty(users))
        {
            throw new ServiceException("该手机号未注册用户");
        }
        SysUser user = users.get(0);
        if (UserConstants.USER_DISABLE.equals(user.getStatus()))
        {
            throw new ServiceException("对不起，您的账号已被停用");
        }

        // 3. 构造LoginUser
        LoginUser loginUser = new LoginUser(user.getUserId(), user.getDeptId(), user, null);
        recordLoginInfo(loginUser.getUserId());

        // 4. 生成token
        return tokenService.createToken(loginUser);
    }

    /**
     * 发送短信验证码 (模拟)
     *
     * @param phonenumber 手机号
     * @return 验证码
     */
    public String sendSmsCode(String phonenumber)
    {
        if (StringUtils.isEmpty(phonenumber))
        {
            throw new ServiceException("手机号不能为空");
        }
        // 校验手机号是否存在
        SysUser userQuery = new SysUser();
        userQuery.setPhonenumber(phonenumber);
        List<SysUser> users = userService.selectUserList(userQuery);
        if (StringUtils.isEmpty(users))
        {
            throw new ServiceException("该手机号未注册");
        }

        // 生成6位随机码
        String code = String.valueOf((int) ((Math.random() * 9 + 1) * 100000));
        String verifyKey = CacheConstants.SMS_CODE_KEY + phonenumber;
        
        // 存入缓存，5分钟有效
        redisCache.setCacheObject(verifyKey, code, 5, TimeUnit.MINUTES);
        
        return code;
    }

    /**
     * 校验验证码
     *
     * @param username 用户名
     * @param code 验证码
     * @param uuid 唯一标识
     * @return 结果
     */
    public void validateCaptcha(String username, String code, String uuid)
    {
        boolean captchaEnabled = configService.selectCaptchaEnabled();
        if (captchaEnabled)
        {
            String verifyKey = CacheConstants.CAPTCHA_CODE_KEY + StringUtils.nvl(uuid, "");
            String captcha = redisCache.getCacheObject(verifyKey);
            if (captcha == null)
            {
                throw new CaptchaExpireException();
            }
            redisCache.deleteObject(verifyKey);
            if (!code.equalsIgnoreCase(captcha))
            {
                throw new CaptchaException();
            }
        }
    }

    /**
     * 登录前置校验
     * @param username 用户名
     * @param password 用户密码
     */
    public void loginPreCheck(String username, String password)
    {
        // 用户名或密码为空 错误
        if (StringUtils.isEmpty(username) || StringUtils.isEmpty(password))
        {
            throw new UserNotExistsException();
        }
        // 密码如果不在指定范围内 错误
        if (password.length() < UserConstants.PASSWORD_MIN_LENGTH
                || password.length() > UserConstants.PASSWORD_MAX_LENGTH)
        {
            throw new UserPasswordNotMatchException();
        }
        // 用户名不在指定范围内 错误
        if (username.length() < UserConstants.USERNAME_MIN_LENGTH
                || username.length() > UserConstants.USERNAME_MAX_LENGTH)
        {
            throw new UserPasswordNotMatchException();
        }
    }

    /**
     * 记录登录信息
     *
     * @param userId 用户ID
     */
    public void recordLoginInfo(Long userId)
    {
        SysUser sysUser = new SysUser();
        sysUser.setUserId(userId);
        sysUser.setLoginIp(IpUtils.getIpAddr());
        sysUser.setLoginDate(DateUtils.getNowDate());
        userService.updateUserProfile(sysUser);
    }
}
