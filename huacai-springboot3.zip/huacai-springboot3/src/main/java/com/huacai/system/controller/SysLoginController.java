package com.huacai.system.controller;

import com.huacai.system.general.constant.Constants;
import com.huacai.system.general.core.domain.AjaxResult;
import com.huacai.system.domain.SysMenu;
import com.huacai.system.domain.SysUser;
import com.huacai.system.general.core.domain.model.LoginBody;
import com.huacai.system.general.core.domain.model.LoginUser;
import com.huacai.system.general.utils.SecurityUtils;
import com.huacai.system.configure.web.service.SysLoginService;
import com.huacai.system.configure.web.service.SysPermissionService;
import com.huacai.system.configure.web.service.TokenService;
import com.huacai.system.service.ISysMenuService;
import com.huacai.system.service.ISysUserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Set;

/**
 * 登录验证
 *
 * @author huacai
 */
@Tag(name = "01-登录认证", description = "登录、获取用户信息、获取路由")
@RestController
public class SysLoginController
{
    @Autowired
    private SysLoginService loginService;

    @Autowired
    private ISysMenuService menuService;

    @Autowired
    private SysPermissionService permissionService;

    @Autowired
    private TokenService tokenService;

    @Autowired
    private ISysUserService userService;

    /**
     * 登录方法
     *
     * @param loginBody 登录信息
     * @return 结果
     */
    @Operation(summary = "登录")
    @PostMapping("/login")
    public AjaxResult login(@RequestBody LoginBody loginBody)
    {
        AjaxResult ajax = AjaxResult.success();
        // 生成令牌
        String token = loginService.login(loginBody.getUsername(), loginBody.getPassword(), loginBody.getCode(),
                loginBody.getUuid());
        ajax.put(Constants.TOKEN, token);
        return ajax;
    }

    /**
     * 手机验证码登录
     *
     * @param loginBody 登录信息
     * @return 结果
     */
    @Operation(summary = "手机验证码登录")
    @PostMapping("/smsLogin")
    public AjaxResult smsLogin(@RequestBody LoginBody loginBody)
    {
        AjaxResult ajax = AjaxResult.success();
        String token = loginService.smsLogin(loginBody.getPhonenumber(), loginBody.getSmsCode());
        ajax.put(Constants.TOKEN, token);
        return ajax;
    }

    /**
     * 获取手机验证码
     *
     * @param loginBody 登录信息
     * @return 结果
     */
    @Operation(summary = "获取手机验证码")
    @PostMapping("/sms/code")
    public AjaxResult getSmsCode(@RequestBody LoginBody loginBody)
    {
        String code = loginService.sendSmsCode(loginBody.getPhonenumber());
        return AjaxResult.success("验证码发送成功", code);
    }

    /**
     * 获取用户信息
     *
     * @return 用户信息
     */
    @Operation(summary = "获取用户信息")
    @GetMapping("getInfo")
    public AjaxResult getInfo()
    {
        LoginUser loginUser = SecurityUtils.getLoginUser();
//        SysUser user = loginUser.getUser();
        SysUser user = userService.selectUserById(loginUser.getUserId());
        // 角色集合
        Set<String> roles = permissionService.getRolePermission(user);
        // 权限集合
        Set<String> permissions = permissionService.getMenuPermission(user);
        if (!loginUser.getPermissions().equals(permissions))
        {
            loginUser.setPermissions(permissions);
            tokenService.refreshToken(loginUser);
        }
        AjaxResult ajax = AjaxResult.success();
        ajax.put("user", user);
        ajax.put("roles", roles);
        ajax.put("permissions", permissions);
        return ajax;
    }

    /**
     * 获取路由信息
     *
     * @return 路由信息
     */
    @Operation(summary = "获取路由信息")
    @GetMapping("getRouters")
    public AjaxResult getRouters()
    {
        Long userId = SecurityUtils.getUserId();
        List<SysMenu> menus = menuService.selectMenuTreeByUserId(userId);
        return AjaxResult.success(menuService.buildMenus(menus));
    }
}