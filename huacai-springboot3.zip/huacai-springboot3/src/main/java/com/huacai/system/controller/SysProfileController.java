package com.huacai.system.controller;

import com.huacai.system.general.config.HuaCaiConfig;
import com.huacai.system.general.core.controller.BaseController;
import com.huacai.system.general.core.domain.AjaxResult;
import com.huacai.system.domain.SysUser;
import com.huacai.system.general.core.domain.model.LoginUser;
import com.huacai.system.general.utils.SecurityUtils;
import com.huacai.system.general.utils.StringUtils;
import com.huacai.system.general.utils.file.FileUploadUtils;
import com.huacai.system.general.utils.file.MimeTypeUtils;
import com.huacai.system.configure.web.service.TokenService;
import com.huacai.system.service.ISysUserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.Map;

/**
 * 个人信息 业务处理
 *
 * @author huacai
 */
@Tag(name = "09-个人信息", description = "个人信息查看、修改密码、头像上传等")
@RestController
@RequestMapping("/system/user/profile")
public class SysProfileController extends BaseController
{
    @Autowired
    private ISysUserService userService;

    @Autowired
    private TokenService tokenService;

    /**
     * 个人信息
     */
    @Operation(summary = "获取个人信息")
    @GetMapping
    public AjaxResult profile()
    {
        LoginUser loginUser = getLoginUser();
        // 直接从数据库获取最新用户信息，避免 JWT 令牌中的数据过时
        SysUser user = userService.selectUserById(loginUser.getUserId());
        AjaxResult ajax = AjaxResult.success(user);
        ajax.put("roleGroup", userService.selectUserRoleGroup(loginUser.getUsername()));
        ajax.put("postGroup", userService.selectUserPostGroup(loginUser.getUsername()));
        return ajax;
    }

    /**
     * 修改用户
     */
    @Operation(summary = "修改个人信息")
    @PutMapping
    public AjaxResult updateProfile(@RequestBody SysUser user)
    {
        // 终极调试：看看前端到底传了什么过来
        logger.info(">>> Receiving profile update. Name: {}, Phone: {}", user.getNickName(), user.getPhonenumber());
        
        LoginUser loginUser = getLoginUser();
        SysUser currentUser = loginUser.getUser();
        
        // 强制提取手机号，防止逻辑覆盖丢失
        if (StringUtils.isNotEmpty(user.getPhonenumber())) {
            currentUser.setPhonenumber(user.getPhonenumber());
        }
        
        currentUser.setNickName(user.getNickName());
        currentUser.setEmail(user.getEmail());
        currentUser.setSex(user.getSex());
        if (StringUtils.isNotEmpty(user.getPhonenumber()) && !userService.checkPhoneUnique(currentUser))
        {
            return error("修改用户'" + loginUser.getUsername() + "'失败，手机号码已存在");
        }
        if (StringUtils.isNotEmpty(user.getEmail()) && !userService.checkEmailUnique(currentUser))
        {
            return error("修改用户'" + loginUser.getUsername() + "'失败，邮箱账号已存在");
        }
        if (userService.updateUserProfile(currentUser) > 0)
        {
            // 更新缓存用户信息
            tokenService.setLoginUser(loginUser);
            return success();
        }
        return error("修改个人信息异常，请联系管理员");
    }

    /**
     * 实名认证
     */
    @Operation(summary = "实名认证")
    @PutMapping("/verify")
    public AjaxResult verify(@RequestBody SysUser user)
    {
        String realName = user.getRealName();
        String idCard = user.getIdCard();

        if (StringUtils.isEmpty(realName) || StringUtils.isEmpty(idCard))
        {
            return error("姓名和身份证号不能为空");
        }

        // 身份证号正则校验 (18位)
        String regex = "^[1-9]\\d{5}(18|19|20)\\d{2}((0[1-9])|(1[0-2]))(([0-2][1-9])|10|20|30|31)\\d{3}[0-9Xx]$";
        if (!idCard.matches(regex))
        {
            return error("身份证号码格式不正确");
        }

        LoginUser loginUser = getLoginUser();
        SysUser currentUser = userService.selectUserById(loginUser.getUserId());
        
        currentUser.setRealName(realName);
        currentUser.setIdCard(idCard);
        currentUser.setIsVerified("1"); // 设置为已认证

        if (userService.updateUserProfile(currentUser) > 0)
        {
            return success("实名认证成功");
        }
        return error("实名认证失败，请联系管理员");
    }

    /**
     * 重置密码
     */
    @Operation(summary = "修改密码")
    @PutMapping("/updatePwd")
    public AjaxResult updatePwd(@RequestBody Map<String, String> params)
    {
        String oldPassword = params.get("oldPassword");
        String newPassword = params.get("newPassword");
        LoginUser loginUser = getLoginUser();
        String userName = loginUser.getUsername();

        // 从数据库获取用户信息，确保密码字段正确
        SysUser user = userService.selectUserByUserName(userName);
        String password = user.getPassword();

        if (!SecurityUtils.matchesPassword(oldPassword, password))
        {
            return error("修改密码失败，旧密码错误");
        }
        if (SecurityUtils.matchesPassword(newPassword, password))
        {
            return error("新密码不能与旧密码相同");
        }
        newPassword = SecurityUtils.encryptPassword(newPassword);
        if (userService.resetUserPwd(userName, newPassword) > 0)
        {
            // 更新缓存用户密码
            loginUser.getUser().setPassword(newPassword);
            tokenService.setLoginUser(loginUser);
            return success();
        }
        return error("修改密码异常，请联系管理员");
    }

    /**
     * 头像上传
     */
    @Operation(summary = "头像上传")
    @PostMapping("/avatar")
    public AjaxResult avatar(@RequestParam("avatarfile") MultipartFile file) throws Exception
    {
        if (!file.isEmpty())
        {
            LoginUser loginUser = getLoginUser();
            String avatar = FileUploadUtils.upload(HuaCaiConfig.getAvatarPath(), file, MimeTypeUtils.IMAGE_EXTENSION);
            if (userService.updateUserAvatar(loginUser.getUsername(), avatar))
            {
                AjaxResult ajax = AjaxResult.success();
                ajax.put("imgUrl", avatar);
                // 更新缓存用户头像
                loginUser.getUser().setAvatar(avatar);
                tokenService.setLoginUser(loginUser);
                return ajax;
            }
        }
        return error("上传图片异常，请联系管理员");
    }
}
