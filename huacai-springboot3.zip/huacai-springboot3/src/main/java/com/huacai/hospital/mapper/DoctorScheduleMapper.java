package com.huacai.hospital.mapper;

import com.huacai.hospital.domain.DoctorSchedule;
import org.apache.ibatis.annotations.Mapper;
import java.util.List;

@Mapper
public interface DoctorScheduleMapper {
    public List<DoctorSchedule> selectDoctorScheduleList(DoctorSchedule schedule);
    public DoctorSchedule selectDoctorScheduleById(Long scheduleId);
    public int insertDoctorSchedule(DoctorSchedule schedule);
    public int updateDoctorSchedule(DoctorSchedule schedule);
    public int deleteDoctorScheduleByIds(Long[] scheduleIds);
    public int reduceScheduleStock(Long scheduleId);
}
