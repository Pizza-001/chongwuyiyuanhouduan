package com.huacai.hospital.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.huacai.system.general.annotation.Excel;
import com.huacai.system.general.core.domain.BaseEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * 宠物档案对象 pet
 *
 * @author huacai
 * @date 2025-10-30
 */
@EqualsAndHashCode(callSuper = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Pet extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /** 宠物ID */
    private String petId;

    /** 绑定用户ID */
    @Excel(name = "绑定用户ID")
    private Long userId;

    /** 宠物昵称 */
    @Excel(name = "宠物昵称")
    private String name;

    /** 宠物头像 */
    @Excel(name = "宠物头像")
    private String avatar;

    /** 种类 */
    @Excel(name = "种类")
    private String type;

    /** 品种 */
    @Excel(name = "品种")
    private String breed;

    /** 性别 (0公 1母 2未知) */
    @Excel(name = "性别", readConverterExp = "0=公,1=母,2=未知")
    private String gender;

    /** 生日 */
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Excel(name = "生日", width = 30, dateFormat = "yyyy-MM-dd")
    private Date birthday;
    
    /** 辅助字段：计算后的年龄 */
    private String age;

    /** 体重(kg) */
    @Excel(name = "体重(kg)")
    private Double weight;

    /** 健康状态 */
    @Excel(name = "健康状态")
    private String healthStatus;

    /** 主人姓名 */
    @Excel(name = "主人姓名")
    private String ownerName;

    /** 联系电话 */
    @Excel(name = "联系电话")
    private String phone;

    /** 当前治疗状态 */
    @Excel(name = "当前治疗状态")
    private String treatmentStatus;

    /** 最后就诊时间 */
    @Excel(name = "最后就诊时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date lastVisitTime;
}
