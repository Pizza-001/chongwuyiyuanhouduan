package com.huacai.hospital.domain;

import com.huacai.system.general.core.domain.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 积分商城商品对象 hospital_points_mall
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class PointsProduct extends BaseEntity {
    private static final long serialVersionUID = 1L;

    private Long id;
    private Long targetId;
    private String type; // MEDICINE / COUPON
    private Long pointsPrice;
    private Integer stock;
    private String status;

    // Join fields (optional, for easy display)
    private String productName;
    private String productImage;
    private String productDesc;
}
