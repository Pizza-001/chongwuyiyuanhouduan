package com.huacai.hospital.service.impl;

import com.huacai.hospital.domain.PointsExchangeRecord;
import com.huacai.hospital.domain.PointsProduct;
import com.huacai.hospital.domain.SysMember;
import com.huacai.hospital.domain.SysUserCoupon;
import com.huacai.hospital.mapper.CouponMapper;
import com.huacai.hospital.mapper.PointsMallMapper;
import com.huacai.hospital.mapper.SysMemberMapper;
import com.huacai.hospital.service.PointsMallService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
public class PointsMallServiceImpl implements PointsMallService {

    @Autowired
    private PointsMallMapper pointsMallMapper;

    @Autowired
    private SysMemberMapper memberMapper;

    @Autowired
    private CouponMapper couponMapper;

    @Override
    public List<PointsProduct> selectPointsProductList(PointsProduct product) {
        return pointsMallMapper.selectPointsProductList(product);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean exchangeProduct(Long productId, Long userId) {
        // 1. 获取商城商品信息
        PointsProduct product = pointsMallMapper.selectPointsProductById(productId);
        if (product == null || !"0".equals(product.getStatus())) {
            throw new RuntimeException("商品已下架");
        }
        if (product.getStock() <= 0) {
            throw new RuntimeException("库存不足");
        }

        // 2. 获取会员积分信息
        SysMember member = memberMapper.selectSysMemberByUserId(userId);
        if (member == null || member.getPoints() < product.getPointsPrice()) {
            throw new RuntimeException("积分不足");
        }

        // 3. 扣减库存
        int rows = pointsMallMapper.reduceMallStock(productId, 1);
        if (rows <= 0) {
            throw new RuntimeException("抢购失败，请稍后再试");
        }

        // 4. 扣减积分
        member.setPoints(member.getPoints() - product.getPointsPrice());
        memberMapper.updateSysMember(member);

        // 5. 交付奖励
        if ("COUPON".equals(product.getType())) {
            SysUserCoupon userCoupon = new SysUserCoupon();
            userCoupon.setUserId(userId);
            userCoupon.setCouponId(product.getTargetId());
            userCoupon.setUseStatus("0");
            couponMapper.insertUserCoupon(userCoupon);
        } else if ("MEDICINE".equals(product.getType())) {
            // 药品兑换：记录已兑换，逻辑上用户需要到店领取
            // 这里可以增加一条取药记录，暂且仅通过兑换记录展示
        }

        // 6. 记录兑换记录
        PointsExchangeRecord record = new PointsExchangeRecord();
        record.setUserId(userId);
        record.setProductId(productId);
        record.setExchangePoints(product.getPointsPrice());
        pointsMallMapper.insertExchangeRecord(record);

        return true;
    }

    @Override
    public List<PointsExchangeRecord> selectExchangeRecordList(Long userId) {
        PointsExchangeRecord record = new PointsExchangeRecord();
        record.setUserId(userId);
        return pointsMallMapper.selectExchangeRecordList(record);
    }

    @Override
    public PointsProduct selectPointsProductById(Long id) {
        return pointsMallMapper.selectPointsProductById(id);
    }

    @Override
    public int insertPointsProduct(PointsProduct product) {
        return pointsMallMapper.insertPointsProduct(product);
    }

    @Override
    public int updatePointsProduct(PointsProduct product) {
        return pointsMallMapper.updatePointsProduct(product);
    }

    @Override
    public int deletePointsProductByIds(Long[] ids) {
        return pointsMallMapper.deletePointsProductByIds(ids);
    }
}
