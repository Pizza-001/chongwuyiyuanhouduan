package com.huacai.hospital.service;

/**
 * 会员成长值Service接口
 */
public interface IMemberGrowthService {
    /**
     * 增加成长值
     * @param userId 用户ID
     * @param amount 变动金额
     * @param type 变动类型
     * @param remark 备注
     */
    public void addGrowth(Long userId, Long amount, String type, String remark);
}
