package com.huacai.hospital.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import java.io.Serializable;
import java.util.Date;

/**
 * 用户优惠券领用记录对象 sys_user_coupon
 */
@Data
public class SysUserCoupon implements Serializable {
    private static final long serialVersionUID = 1L;

    private Long id;
    private Long userId;
    private Long couponId;
    private String useStatus; // 0 未使用, 1 已使用

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date useTime;

    private String orderNo;

    // 关联字段 (方便前端展示)
    private SysCoupon coupon;
}
