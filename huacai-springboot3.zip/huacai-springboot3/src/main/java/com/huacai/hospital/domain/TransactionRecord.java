package com.huacai.hospital.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.huacai.system.general.annotation.Excel;
import com.huacai.system.general.core.domain.BaseEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.Date;

/**
 * 交易流水明细 transaction_record
 */
@EqualsAndHashCode(callSuper = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TransactionRecord extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /** 交易ID */
    private String id;

    /** 用户ID */
    @Excel(name = "用户ID")
    private Long userId;

    /** 交易类型 (RECHARGE 充值, CONSUME 消费) */
    @Excel(name = "交易类型")
    private String type;

    /** 交易金额 */
    @Excel(name = "交易金额")
    private BigDecimal amount;

    /** 支付方式 (ALIPAY 支付宝, WECHAT 微信, BANKCARD 银行卡, UNIONPAY 云闪付, BALANCE 余额支付) */
    @Excel(name = "支付方式")
    private String paymentMethod;

    /** 本次交易产生的积分 */
    @Excel(name = "产生积分")
    private Long pointsEarned;

}
