package com.huacai.hospital.service;

import com.huacai.hospital.domain.SysMember;
import java.math.BigDecimal;
import java.util.List;

/**
 * 会员档案Service接口
 */
public interface ISysMemberService {
    
    public SysMember selectSysMemberById(Long memberId);
    
    public SysMember selectSysMemberByUserId(Long userId);

    public List<SysMember> selectSysMemberList(SysMember sysMember);

    public int insertSysMember(SysMember sysMember);

    public int updateSysMember(SysMember sysMember);

    public int deleteSysMemberById(Long memberId);
    
    /**
     * 为用户充值
     * @param userId 用户
     * @param amount 充值金额
     * @param paymentMethod 支付渠道
     * @return 结果
     */
    public boolean recharge(Long userId, BigDecimal amount, String paymentMethod);
    
    /**
     * 消费行为 (扣款并按1元=1分产生积分)
     * @param userId 用户
     * @param amount 消费金额
     * @param remark 备注(订单号等)
     * @return 结果
     */
    public boolean consume(Long userId, BigDecimal amount, String remark);
}
