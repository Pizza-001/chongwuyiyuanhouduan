package com.huacai.hospital.controller;

import com.huacai.hospital.domain.DoctorSchedule;
import com.huacai.hospital.service.IDoctorScheduleService;
import com.huacai.system.general.core.controller.BaseController;
import com.huacai.system.general.core.domain.AjaxResult;
import com.huacai.system.general.core.page.TableDataInfo;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@Tag(name = "20-医生排班管理", description = "设置医生出诊时间、号源数")
@RestController
@RequestMapping("/hospital/schedule")
public class DoctorScheduleController extends BaseController {
    @Autowired
    private IDoctorScheduleService scheduleService;

    @Operation(summary = "查询排班列表")
    @GetMapping("/list")
    public TableDataInfo list(DoctorSchedule schedule) {
        startPage();
        List<DoctorSchedule> list = scheduleService.selectDoctorScheduleList(schedule);
        return getDataTable(list);
    }

    @Operation(summary = "获取排班详情")
    @GetMapping("/{id}")
    public AjaxResult getInfo(@PathVariable Long id) {
        return success(scheduleService.selectDoctorScheduleById(id));
    }

    @Operation(summary = "新增排班")
    @PreAuthorize("@ss.hasPermi('hospital:schedule:add')")
    @PostMapping
    public AjaxResult add(@RequestBody DoctorSchedule schedule) {
        return toAjax(scheduleService.insertDoctorSchedule(schedule));
    }

    @Operation(summary = "修改排班")
    @PreAuthorize("@ss.hasPermi('hospital:schedule:edit')")
    @PutMapping
    public AjaxResult edit(@RequestBody DoctorSchedule schedule) {
        return toAjax(scheduleService.updateDoctorSchedule(schedule));
    }

    @Operation(summary = "删除排班")
    @PreAuthorize("@ss.hasPermi('hospital:schedule:remove')")
    @DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids) {
        return toAjax(scheduleService.deleteDoctorScheduleByIds(ids));
    }
}
