package com.huacai.hospital.mapper;

import com.huacai.hospital.domain.Billing;
import java.util.List;

/**
 * 收银结算Mapper接口
 */
public interface BillingMapper {
    /**
     * 查询结算记录
     */
    public Billing selectBillingById(String id);

    /**
     * 查询结算记录列表
     */
    public List<Billing> selectBillingList(Billing billing);

    /**
     * 新增结算记录
     */
    public int insertBilling(Billing billing);

    /**
     * 修改结算记录
     */
    public int updateBilling(Billing billing);

    /**
     * 删除结算记录
     */
    public int deleteBillingById(String id);
    public int deleteBillingByIds(String[] ids);

    /** 财务总额统计 */
    public java.math.BigDecimal selectTotalRevenue();
    public java.math.BigDecimal selectTodayRevenue();
}
