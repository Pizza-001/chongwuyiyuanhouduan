package com.huacai.hospital.domain;

import com.huacai.system.general.core.domain.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import java.util.Date;

/**
 * 积分兑换记录对象 hospital_points_exchange_record
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class PointsExchangeRecord extends BaseEntity {
    private static final long serialVersionUID = 1L;

    private Long id;
    private Long userId;
    private Long productId;
    private Long exchangePoints;
    private Date exchangeTime;
    private String status; // 0已兑换 1已完成 2已取消

    // Join fields
    private String productName;
    private String productType;
}
