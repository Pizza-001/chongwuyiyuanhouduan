package com.huacai.hospital.mapper;

import java.util.List;
import com.huacai.hospital.domain.MedicalRecord;

/**
 * 宠物医疗记录Mapper接口
 */
public interface MedicalRecordMapper 
{
    /**
     * 查询宠物医疗记录
     * 
     * @param recordId 宠物医疗记录ID
     * @return 宠物医疗记录
     */
    public MedicalRecord selectMedicalRecordById(String recordId);

    /**
     * 查询宠物医疗记录列表
     * 
     * @param medicalRecord 宠物医疗记录
     * @return 宠物医疗记录集合
     */
    public List<MedicalRecord> selectMedicalRecordList(MedicalRecord medicalRecord);

    /**
     * 新增宠物医疗记录
     * 
     * @param medicalRecord 宠物医疗记录
     * @return 结果
     */
    public int insertMedicalRecord(MedicalRecord medicalRecord);

    /**
     * 修改宠物医疗记录
     * 
     * @param medicalRecord 宠物医疗记录
     * @return 结果
     */
    public int updateMedicalRecord(MedicalRecord medicalRecord);

    /**
     * 删除宠物医疗记录
     * 
     * @param recordId 宠物医疗记录ID
     * @return 结果
     */
    public int deleteMedicalRecordById(String recordId);

    /**
     * 批量删除宠物医疗记录
     * 
     * @param recordIds 需要删除的数据ID
     * @return 结果
     */
    public int deleteMedicalRecordByIds(String[] recordIds);
}
