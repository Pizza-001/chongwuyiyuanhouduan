package com.huacai.hospital.domain;

import com.huacai.system.general.core.domain.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import java.math.BigDecimal;

/**
 * 药品信息对象 hospital_medicine
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class Medicine extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    private Long medicineId;
    private String name;
    private String specification;
    private String unit;
    private BigDecimal price;
    private Integer stock;
    private String type;
    private String status;
    private String image;
    private String description;
}
