package com.huacai.hospital.mapper;

import com.huacai.hospital.domain.Medicine;
import org.apache.ibatis.annotations.Param;
import java.util.List;

/**
 * 药品信息Mapper接口
 */
public interface MedicineMapper {
    public Medicine selectMedicineByMedicineId(Long medicineId);
    public List<Medicine> selectMedicineList(Medicine medicine);
    public int insertMedicine(Medicine medicine);
    public int updateMedicine(Medicine medicine);
    public int deleteMedicineByMedicineId(Long medicineId);
    public int deleteMedicineByMedicineIds(Long[] medicineIds);
    public List<String> selectMedicineCategories();
    
    /**
     * 减少库存
     * @param id 药品ID
     * @param count 减少数量
     * @return 结果
     */
    public int reduceStock(@Param("id") Long id, @Param("count") Integer count);
}
