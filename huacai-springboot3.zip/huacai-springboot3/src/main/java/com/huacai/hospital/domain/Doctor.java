package com.huacai.hospital.domain;

import com.huacai.system.general.annotation.Excel;
import com.huacai.system.general.core.domain.BaseEntity;
import lombok.*;

/**
 * 医生对象 doctor
 *
 * @author huacai
 * @date 2025-10-27
 */
@EqualsAndHashCode(callSuper = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Doctor extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 医生ID */
    private String doctorId;

    /** 姓名 */
    @Excel(name = "姓名")
    private String name;

    /** 职称 */
    @Excel(name = "职称")
    private String title;

    /** 擅长 */
    @Excel(name = "擅长")
    private String specialty;

    /** 状态 (0在岗 1会诊 2应急 3休假) */
    @Excel(name = "状态", readConverterExp = "0=在岗,1=会诊,2=应急,3=休假")
    private String status;

    /** 执业年限 */
    @Excel(name = "执业年限")
    private String experience;

    /** 评分 */
    @Excel(name = "评分")
    private Double rating;

    /** 挂号费 */
    @Excel(name = "挂号费")
    private Double fee;

    /** 头像 (对应前端 avatar/photo) */
    @Excel(name = "头像")
    private String avatar;

}
