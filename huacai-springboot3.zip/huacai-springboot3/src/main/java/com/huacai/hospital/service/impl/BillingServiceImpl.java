package com.huacai.hospital.service.impl;

import com.huacai.hospital.domain.Billing;
import com.huacai.hospital.domain.SysCoupon;
import com.huacai.hospital.domain.SysMember;
import com.huacai.hospital.domain.SysUserCoupon;
import com.huacai.hospital.domain.SysPointsRecord;
import com.huacai.hospital.mapper.BillingMapper;
import com.huacai.hospital.mapper.CouponMapper;
import com.huacai.hospital.mapper.MedicineMapper;
import com.huacai.hospital.mapper.SysMemberMapper;
import com.huacai.hospital.mapper.SysPointsRecordMapper;
import com.huacai.hospital.service.IBillingService;
import com.huacai.system.general.utils.DateUtils;
import com.huacai.system.general.utils.SecurityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * 收银结算Service业务层处理
 */
@Service
public class BillingServiceImpl implements IBillingService {
    @Autowired
    private BillingMapper billingMapper;
    
    @Autowired
    private CouponMapper couponMapper;
    
    @Autowired
    private SysMemberMapper memberMapper;

    @Autowired
    private MedicineMapper medicineMapper;

    @Autowired
    private SysPointsRecordMapper pointsRecordMapper;

    @Autowired
    private IMemberGrowthService growthService;

    @Override
    public Billing selectBillingById(String id) {
        return billingMapper.selectBillingById(id);
    }

    @Override
    public List<Billing> selectBillingList(Billing billing) {
        return billingMapper.selectBillingList(billing);
    }

    @Override
    public int insertBilling(Billing billing) {
        billing.setId(UUID.randomUUID().toString());
        billing.setCreateTime(DateUtils.getNowDate());
        if (billing.getStatus() == null) billing.setStatus("0");
        return billingMapper.insertBilling(billing);
    }

    @Override
    public int updateBilling(Billing billing) {
        billing.setUpdateTime(DateUtils.getNowDate());
        return billingMapper.updateBilling(billing);
    }

    @Override
    public int deleteBillingByIds(String[] ids) {
        int result = 0;
        for (String id : ids) {
            result += billingMapper.deleteBillingById(id);
        }
        return result;
    }

    @Override
    @Transactional
    public int settle(String billingId, String paymentMethod, Long userCouponId, List<Map<String, Object>> items) {
        Billing billing = billingMapper.selectBillingById(billingId);
        if (billing == null || !"0".equals(billing.getStatus())) {
            throw new RuntimeException("账单不存在或已结算");
        }

        BigDecimal finalPayAmount = billing.getTotalAmount();
        BigDecimal discount = BigDecimal.ZERO;

        // 1. 处理优惠券
        if (userCouponId != null) {
            SysUserCoupon userCoupon = couponMapper.selectUserCouponById(userCouponId);
            if (userCoupon != null && "0".equals(userCoupon.getUseStatus())) {
                if (finalPayAmount.compareTo(userCoupon.getCoupon().getMinSpend()) >= 0) {
                    if ("CASH".equals(userCoupon.getCoupon().getType())) {
                        discount = userCoupon.getCoupon().getAmount();
                    } else if ("PERCENT".equals(userCoupon.getCoupon().getType())) {
                        discount = finalPayAmount.multiply(BigDecimal.ONE.subtract(userCoupon.getCoupon().getAmount()));
                    }
                    finalPayAmount = finalPayAmount.subtract(discount);
                    if (finalPayAmount.compareTo(BigDecimal.ZERO) < 0) finalPayAmount = BigDecimal.ZERO;

                    userCoupon.setUseStatus("1");
                    userCoupon.setUseTime(DateUtils.getNowDate());
                    userCoupon.setOrderNo(billing.getOrderNo());
                    couponMapper.updateUserCouponStatus(userCoupon);
                }
            }
        }

        // 2. 处理支付方式 & 扣减库存
        Long userId = SecurityUtils.getUserId();
        if ("BALANCE".equals(paymentMethod)) {
            SysMember member = memberMapper.selectSysMemberByUserId(userId);
            if (member == null || member.getBalance().compareTo(finalPayAmount) < 0) {
                throw new RuntimeException("会员账户余额不足");
            }
            member.setBalance(member.getBalance().subtract(finalPayAmount));
            memberMapper.updateSysMember(member);
        }

        // 扣减库存逻辑
        if (items != null) {
            for (Map<String, Object> item : items) {
                Long medId = Long.valueOf(item.get("medicineId").toString());
                Integer count = Integer.valueOf(item.get("count").toString());
                int res = medicineMapper.reduceStock(medId, count);
                if (res <= 0) {
                    throw new RuntimeException("商品库存不足，结算失败");
                }
            }
        }

        // 3. 统一增加积分 (消费1元积1分) & 成长值 (消费1元积10点)
        if (finalPayAmount.compareTo(BigDecimal.ZERO) > 0) {
            SysMember member = memberMapper.selectSysMemberByUserId(userId);
            if (member != null) {
                long earnedPoints = finalPayAmount.setScale(0, RoundingMode.HALF_UP).longValue();
                Long currentPoints = member.getPoints() != null ? member.getPoints() : 0L;
                Long currentTotalPoints = member.getTotalPoints() != null ? member.getTotalPoints() : 0L;
                
                member.setPoints(currentPoints + earnedPoints);
                member.setTotalPoints(currentTotalPoints + earnedPoints);
                memberMapper.updateSysMember(member);

                // 调用企业级成长值系统
                long earnedGrowth = finalPayAmount.multiply(new BigDecimal(10)).setScale(0, RoundingMode.HALF_UP).longValue();
                growthService.addGrowth(userId, earnedGrowth, "CONSUMPTION", "药房购药: " + billing.getOrderNo());

                // 增加积分记录
                SysPointsRecord record = new SysPointsRecord();
                record.setUserId(userId);
                record.setTitle("药房购药奖励");
                record.setChangePoints(earnedPoints);
                record.setType("plus");
                pointsRecordMapper.insertPointsRecord(record);
            }
        }

        // 4. 更新账单状态
        billing.setDiscountAmount(discount);
        billing.setPayAmount(finalPayAmount);
        billing.setStatus("1");
        billing.setPaymentMethod(paymentMethod);
        billing.setPaymentTime(DateUtils.getNowDate());
        
        return billingMapper.updateBilling(billing);
    }

    @Override
    public List<SysUserCoupon> selectMemberCoupons(Long userId) {
        return couponMapper.selectMemberCoupons(userId);
    }

    @Override
    public List<SysCoupon> selectCouponList(SysCoupon coupon) {
        return couponMapper.selectCouponList(coupon);
    }

    @Override
    public int insertCoupon(SysCoupon coupon) {
        return couponMapper.insertCoupon(coupon);
    }

    @Override
    public int updateCoupon(SysCoupon coupon) {
        return couponMapper.updateCoupon(coupon);
    }

    @Override
    public int deleteCouponByIds(Long[] couponIds) {
        return couponMapper.deleteCouponByIds(couponIds);
    }

    @Override
    public int grantCoupon(Long userId, Long couponId) {
        SysUserCoupon uc = new SysUserCoupon();
        uc.setUserId(userId);
        uc.setCouponId(couponId);
        uc.setUseStatus("0");
        return couponMapper.insertUserCoupon(uc);
    }

    @Override
    public java.math.BigDecimal selectTotalRevenue() {
        return billingMapper.selectTotalRevenue();
    }

    @Override
    public java.math.BigDecimal selectTodayRevenue() {
        return billingMapper.selectTodayRevenue();
    }
}
