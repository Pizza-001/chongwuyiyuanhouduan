package com.huacai.hospital.mapper;

import com.huacai.hospital.domain.SysCoupon;
import com.huacai.hospital.domain.SysUserCoupon;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.util.List;

@Mapper
public interface CouponMapper {
    /**
     * 查询优惠券模板列表
     */
    public List<SysCoupon> selectCouponList(SysCoupon coupon);

    /**
     * 新增优惠券模板
     */
    public int insertCoupon(SysCoupon coupon);

    /**
     * 修改优惠券模板
     */
    public int updateCoupon(SysCoupon coupon);

    /**
     * 删除优惠券模板
     */
    public int deleteCouponByIds(Long[] couponIds);

    /**
     * 插入用户优惠券领用记录
     */
    public int insertUserCoupon(SysUserCoupon userCoupon);
    /**
     * 查询用户可用的优惠券列表
     */
    public List<SysUserCoupon> selectMemberCoupons(@Param("userId") Long userId);

    /**
     * 查询单条领用记录
     */
    public SysUserCoupon selectUserCouponById(Long id);

    /**
     * 更新优惠券使用状态
     */
    public int updateUserCouponStatus(SysUserCoupon userCoupon);
}
