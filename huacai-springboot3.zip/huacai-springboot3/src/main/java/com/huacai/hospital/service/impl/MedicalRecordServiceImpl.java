package com.huacai.hospital.service.impl;

import java.util.List;
import com.huacai.system.general.utils.DateUtils;
import com.huacai.system.general.utils.uuid.IdUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.huacai.hospital.mapper.MedicalRecordMapper;
import com.huacai.hospital.domain.MedicalRecord;
import com.huacai.hospital.service.IMedicalRecordService;

/**
 * 宠物医疗记录Service业务层处理
 */
@Service
public class MedicalRecordServiceImpl implements IMedicalRecordService 
{
    @Autowired
    private MedicalRecordMapper medicalRecordMapper;

    /**
     * 查询宠物医疗记录
     * 
     * @param recordId 宠物医疗记录ID
     * @return 宠物医疗记录
     */
    @Override
    public MedicalRecord selectMedicalRecordById(String recordId)
    {
        return medicalRecordMapper.selectMedicalRecordById(recordId);
    }

    /**
     * 查询宠物医疗记录列表
     * 
     * @param medicalRecord 宠物医疗记录
     * @return 宠物医疗记录
     */
    @Override
    public List<MedicalRecord> selectMedicalRecordList(MedicalRecord medicalRecord)
    {
        return medicalRecordMapper.selectMedicalRecordList(medicalRecord);
    }

    /**
     * 新增宠物医疗记录
     * 
     * @param medicalRecord 宠物医疗记录
     * @return 结果
     */
    @Override
    public int insertMedicalRecord(MedicalRecord medicalRecord)
    {
        medicalRecord.setRecordId(IdUtils.fastSimpleUUID());
        medicalRecord.setCreateTime(DateUtils.getNowDate());
        return medicalRecordMapper.insertMedicalRecord(medicalRecord);
    }

    /**
     * 修改宠物医疗记录
     * 
     * @param medicalRecord 宠物医疗记录
     * @return 结果
     */
    @Override
    public int updateMedicalRecord(MedicalRecord medicalRecord)
    {
        medicalRecord.setUpdateTime(DateUtils.getNowDate());
        return medicalRecordMapper.updateMedicalRecord(medicalRecord);
    }

    /**
     * 批量删除宠物医疗记录
     * 
     * @param recordIds 需要删除的宠物医疗记录ID
     * @return 结果
     */
    @Override
    public int deleteMedicalRecordByIds(String[] recordIds)
    {
        return medicalRecordMapper.deleteMedicalRecordByIds(recordIds);
    }

    /**
     * 删除宠物医疗记录信息
     * 
     * @param recordId 宠物医疗记录ID
     * @return 结果
     */
    @Override
    public int deleteMedicalRecordById(String recordId)
    {
        return medicalRecordMapper.deleteMedicalRecordById(recordId);
    }
}
