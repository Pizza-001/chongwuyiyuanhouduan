package com.huacai.hospital.mapper;

import com.huacai.hospital.domain.SysGrowthRecord;
import java.util.List;

/**
 * 会员成长值流水Mapper接口
 */
public interface SysGrowthRecordMapper {
    /**
     * 新增成长值流水
     */
    public int insertGrowthRecord(SysGrowthRecord record);

    /**
     * 查询成长值流水列表
     */
    public List<SysGrowthRecord> selectGrowthRecordList(SysGrowthRecord record);
}
