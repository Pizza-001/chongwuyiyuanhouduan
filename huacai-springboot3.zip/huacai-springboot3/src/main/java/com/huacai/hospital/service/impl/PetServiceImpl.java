package com.huacai.hospital.service.impl;

import java.util.Calendar;
import java.util.List;
import com.huacai.system.general.utils.DateUtils;
import com.huacai.system.general.utils.SecurityUtils;
import com.huacai.system.general.utils.uuid.IdUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.huacai.hospital.mapper.PetMapper;
import com.huacai.hospital.domain.Pet;
import com.huacai.hospital.service.IPetService;

/**
 * 宠物档案Service业务层处理
 */
@Service
public class PetServiceImpl implements IPetService {
    @Autowired
    private PetMapper petMapper;

    @Override
    public Pet selectPetById(String petId) {
        Pet pet = petMapper.selectPetById(petId);
        if (pet != null) {
            calculateAge(pet);
        }
        return pet;
    }

    @Override
    public List<Pet> selectPetList(Pet pet) {
        List<Pet> list = petMapper.selectPetList(pet);
        for (Pet p : list) {
            calculateAge(p);
        }
        return list;
    }

    private void calculateAge(Pet pet) {
        if (pet.getBirthday() != null) {
            Calendar birth = Calendar.getInstance();
            birth.setTime(pet.getBirthday());
            Calendar now = Calendar.getInstance();
            int age = now.get(Calendar.YEAR) - birth.get(Calendar.YEAR);
            if (now.get(Calendar.DAY_OF_YEAR) < birth.get(Calendar.DAY_OF_YEAR)) {
                age--;
            }
            pet.setAge(age <= 0 ? "1岁以内" : age + "岁");
        }
    }

    @Override
    public int insertPet(Pet pet) {
        pet.setPetId("P" + IdUtils.fastSimpleUUID().substring(0, 8).toUpperCase());
        pet.setCreateTime(DateUtils.getNowDate());
        try {
            pet.setCreateBy(SecurityUtils.getUsername());
        } catch (Exception e) {
            pet.setCreateBy("system");
        }
        return petMapper.insertPet(pet);
    }

    @Override
    public int updatePet(Pet pet) {
        pet.setUpdateTime(DateUtils.getNowDate());
        try {
            pet.setUpdateBy(SecurityUtils.getUsername());
        } catch (Exception e) {
            pet.setUpdateBy("system");
        }
        return petMapper.updatePet(pet);
    }

    @Override
    public int deletePetByIds(String[] petIds) {
        return petMapper.deletePetByIds(petIds);
    }

    @Override
    public int deletePetById(String petId) {
        return petMapper.deletePetById(petId);
    }
}
