package com.huacai.hospital.service;

import java.util.List;
import com.huacai.hospital.domain.Medicine;

/**
 * 药品Service接口
 */
public interface IMedicineService 
{
    /**
     * 查询药品
     */
    public Medicine selectMedicineByMedicineId(Long medicineId);

    /**
     * 查询药品列表
     */
    public List<Medicine> selectMedicineList(Medicine medicine);

    /**
     * 新增药品
     */
    public int insertMedicine(Medicine medicine);

    /**
     * 修改药品
     */
    public int updateMedicine(Medicine medicine);

    /**
     * 批量删除药品
     */
    public int deleteMedicineByMedicineIds(Long[] medicineIds);

    /**
     * 删除药品信息
     */
    public int deleteMedicineByMedicineId(Long medicineId);

    /**
     * 获取所有药品分类
     */
    public List<String> selectMedicineCategories();
}
