package com.huacai.hospital.domain;

import com.huacai.system.general.annotation.Excel;
import com.huacai.system.general.core.domain.BaseEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

/**
 * 会员档案对象 sys_member
 */
@EqualsAndHashCode(callSuper = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class SysMember extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /** 会员ID */
    private Long memberId;

    /** 用户ID (关联sys_user表) */
    @Excel(name = "关联用户ID")
    private Long userId;

    /** 会员等级 (0青铜 1白银 2黄金 3铂金 4钻石) */
    @Excel(name = "会员等级", readConverterExp = "0=青铜,1=白银,2=黄金,3=铂金,4=钻石")
    private String level;

    /** 账户余额 */
    @Excel(name = "账户余额")
    private BigDecimal balance;

    /** 成长值 (1元=10点) */
    @Excel(name = "成长值")
    private Long growthValue;

    /** 当前可用积分 (1元=1分) */
    @Excel(name = "可用积分")
    private Long points;

    /** 累计获得总积分 */
    @Excel(name = "累计总积分")
    private Long totalPoints;

}
