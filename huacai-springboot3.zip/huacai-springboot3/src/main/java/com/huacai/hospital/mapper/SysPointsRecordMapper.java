package com.huacai.hospital.mapper;

import com.huacai.hospital.domain.SysPointsRecord;
import java.util.List;

/**
 * 积分记录Mapper接口
 */
public interface SysPointsRecordMapper {
    public int insertPointsRecord(SysPointsRecord record);
    public List<SysPointsRecord> selectPointsRecordList(SysPointsRecord record);
}
