package com.huacai.hospital.service;

import com.huacai.hospital.domain.DoctorSchedule;
import java.util.List;

public interface IDoctorScheduleService {
    public List<DoctorSchedule> selectDoctorScheduleList(DoctorSchedule schedule);
    public DoctorSchedule selectDoctorScheduleById(Long scheduleId);
    public int insertDoctorSchedule(DoctorSchedule schedule);
    public int updateDoctorSchedule(DoctorSchedule schedule);
    public int deleteDoctorScheduleByIds(Long[] scheduleIds);
}
