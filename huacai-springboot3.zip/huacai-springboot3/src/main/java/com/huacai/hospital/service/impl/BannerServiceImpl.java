package com.huacai.hospital.service.impl;

import java.util.List;

import com.huacai.system.general.utils.uuid.IdUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.huacai.hospital.mapper.BannerMapper;
import com.huacai.hospital.domain.Banner;
import com.huacai.hospital.service.IBannerService;
import org.apache.ibatis.session.ExecutorType;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.util.CollectionUtils;

/**
 * 轮播图Service业务层处理
 *
 * @author huacai
 * @date 2025-10-26
 */
@Service
public class BannerServiceImpl implements IBannerService {
    @Autowired
    private BannerMapper bannerMapper;

    @Autowired
    private SqlSessionFactory sqlSessionFactory;

    /**
     * 查询轮播图
     *
     * @param bannerId 轮播图主键
     * @return 轮播图
     */
    @Override
    public Banner selectBannerByBannerId(String bannerId) {
        return bannerMapper.selectBannerByBannerId(bannerId);
    }

    /**
     * 查询轮播图列表
     *
     * @param banner 轮播图
     * @return 轮播图
     */
    @Override
    public List<Banner> selectBannerList(Banner banner) {
        return bannerMapper.selectBannerList(banner);
    }

    /**
     * 新增轮播图
     *
     * @param banner 轮播图
     * @return 结果
     */
    @Override
    public int insertBanner(Banner banner) {
        //生成一个新的UUID并插入至轮播图对象中
        banner.setBannerId(IdUtils.fastSimpleUUID());
        return bannerMapper.insertBanner(banner);
    }

    /**
     * 批量新增轮播图
     *
     * @param banners 轮播图List
     * @return 结果
     */
    @Override
    public int batchInsertBanner(List<Banner> banners) {
        if (CollectionUtils.isEmpty(banners)) {
            return 0;
        }
        
        int count = 0;
        SqlSession sqlSession = sqlSessionFactory.openSession(ExecutorType.BATCH, false);
        try {
            BannerMapper mapper = sqlSession.getMapper(BannerMapper.class);
            for (int i = 0; i < banners.size(); i++) {
                Banner banner = banners.get(i);
                if (banner.getBannerId() == null) {
                    banner.setBannerId(IdUtils.fastSimpleUUID());
                }
                mapper.insertBanner(banner);
                
                // 每100条提交一次
                if ((i + 1) % 100 == 0 || (i + 1) == banners.size()) {
                    sqlSession.commit();
                    sqlSession.clearCache();
                }
                count++;
            }
        } catch (Exception e) {
            sqlSession.rollback();
            throw e; // 向上抛出异常，让前端捕获
        } finally {
            sqlSession.close();
        }
        return count;
    }

    /**
     * 修改轮播图
     *
     * @param banner 轮播图
     * @return 结果
     */
    @Override
    public int updateBanner(Banner banner) {
        return bannerMapper.updateBanner(banner);
    }

    /**
     * 批量删除轮播图
     *
     * @param bannerIds 需要删除的轮播图主键
     * @return 结果
     */
    @Override
    public int deleteBannerByBannerIds(String[] bannerIds) {
        return bannerMapper.deleteBannerByBannerIds(bannerIds);
    }

    /**
     * 删除轮播图信息
     *
     * @param bannerId 轮播图主键
     * @return 结果
     */
    @Override
    public int deleteBannerByBannerId(String bannerId) {
        return bannerMapper.deleteBannerByBannerId(bannerId);
    }
}
