package com.huacai.hospital.controller;

import com.huacai.system.general.core.controller.BaseController;
import com.huacai.system.general.core.domain.AjaxResult;
import com.huacai.system.general.utils.SecurityUtils;
import com.huacai.hospital.domain.SysMember;
import com.huacai.hospital.domain.SysPointsRecord;
import com.huacai.hospital.mapper.SysPointsRecordMapper;
import com.huacai.hospital.service.ISysMemberService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

/**
 * 会员资产Controller
 */
@RestController
@RequestMapping("/hospital/member")
public class SysMemberController extends BaseController {

    @Autowired
    private ISysMemberService memberService;

    @Autowired
    private SysPointsRecordMapper pointsRecordMapper;

    /**
     * 获取积分记录
     */
    @GetMapping("/pointsRecords")
    public AjaxResult getPointsRecords() {
        Long userId = SecurityUtils.getUserId();
        SysPointsRecord record = new SysPointsRecord();
        record.setUserId(userId);
        List<SysPointsRecord> list = pointsRecordMapper.selectPointsRecordList(record);
        return success(list);
    }
    /**
     * 查询会员列表 (后台管理使用)
     */
    @GetMapping("/list")
    public AjaxResult list(SysMember member) {
        return success(memberService.selectSysMemberList(member));
    }

    /**
     * 获取当前登录用户的会员信息
     */
    @GetMapping("/info")
    public AjaxResult getMemberInfo() {
        Long userId = SecurityUtils.getUserId();
        SysMember member = memberService.selectSysMemberByUserId(userId);
        return success(member);
    }

    /**
     * 会员充值 (模拟微信/支付宝等)
     */
    @PostMapping("/recharge")
    public AjaxResult recharge(@RequestBody Map<String, Object> params) {
        Long userId = SecurityUtils.getUserId();
        if (params.get("amount") == null || params.get("paymentMethod") == null) {
            return error("参数不完整");
        }
        BigDecimal amount = new BigDecimal(params.get("amount").toString());
        String method = params.get("paymentMethod").toString();
        
        try {
            memberService.recharge(userId, amount, method);
            return success("充值成功");
        } catch (Exception e) {
            return error(e.getMessage());
        }
    }
}
