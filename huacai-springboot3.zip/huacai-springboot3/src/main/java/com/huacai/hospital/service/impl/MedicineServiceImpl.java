package com.huacai.hospital.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.huacai.hospital.domain.Medicine;
import com.huacai.hospital.mapper.MedicineMapper;
import com.huacai.hospital.service.IMedicineService;

/**
 * 药品Service业务层处理
 */
@Service
public class MedicineServiceImpl implements IMedicineService 
{
    @Autowired
    private MedicineMapper medicineMapper;

    @Override
    public Medicine selectMedicineByMedicineId(Long medicineId)
    {
        return medicineMapper.selectMedicineByMedicineId(medicineId);
    }

    @Override
    public List<Medicine> selectMedicineList(Medicine medicine)
    {
        return medicineMapper.selectMedicineList(medicine);
    }

    @Override
    public int insertMedicine(Medicine medicine)
    {
        return medicineMapper.insertMedicine(medicine);
    }

    @Override
    public int updateMedicine(Medicine medicine)
    {
        return medicineMapper.updateMedicine(medicine);
    }

    @Override
    public int deleteMedicineByMedicineIds(Long[] medicineIds)
    {
        return medicineMapper.deleteMedicineByMedicineIds(medicineIds);
    }

    @Override
    public int deleteMedicineByMedicineId(Long medicineId)
    {
        return medicineMapper.deleteMedicineByMedicineId(medicineId);
    }

    @Override
    public List<String> selectMedicineCategories() {
        return medicineMapper.selectMedicineCategories();
    }
}
