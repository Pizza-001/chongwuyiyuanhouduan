package com.huacai.hospital.service;

import com.huacai.hospital.domain.Pet;
import java.util.List;

/**
 * 宠物档案Service接口
 */
public interface IPetService {
    public Pet selectPetById(String petId);
    public List<Pet> selectPetList(Pet pet);
    public int insertPet(Pet pet);
    public int updatePet(Pet pet);
    public int deletePetByIds(String[] petIds);
    public int deletePetById(String petId);
}
