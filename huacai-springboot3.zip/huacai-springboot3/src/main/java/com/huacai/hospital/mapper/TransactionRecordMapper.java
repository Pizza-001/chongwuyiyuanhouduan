package com.huacai.hospital.mapper;

import com.huacai.hospital.domain.TransactionRecord;
import org.apache.ibatis.annotations.Mapper;
import java.util.List;

@Mapper
public interface TransactionRecordMapper {
    public int insertTransactionRecord(TransactionRecord transactionRecord);
    public List<TransactionRecord> selectTransactionRecordList(TransactionRecord transactionRecord);
}
