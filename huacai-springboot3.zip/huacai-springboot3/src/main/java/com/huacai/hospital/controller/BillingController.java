package com.huacai.hospital.controller;

import com.huacai.hospital.domain.Billing;
import com.huacai.hospital.domain.SysCoupon;
import com.huacai.hospital.service.IBillingService;
import com.huacai.system.general.core.controller.BaseController;
import com.huacai.system.general.core.domain.AjaxResult;
import com.huacai.system.general.core.page.TableDataInfo;
import com.huacai.system.general.utils.SecurityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

/**
 * 收银结算Controller
 */
@RestController
@RequestMapping("/hospital/billing")
public class BillingController extends BaseController {
    @Autowired
    private IBillingService billingService;

    /**
     * 查询结算记录列表
     */
    @GetMapping("/list")
    public TableDataInfo list(Billing billing) {
        startPage();
        List<Billing> list = billingService.selectBillingList(billing);
        return getDataTable(list);
    }

    /**
     * 获取用户可用优惠券
     */
    @GetMapping("/myCoupons")
    public AjaxResult myCoupons() {
        return success(billingService.selectMemberCoupons(SecurityUtils.getUserId()));
    }

    /**
     * 查询优惠券模板列表 (后台管理使用)
     */
    @GetMapping("/couponList")
    public AjaxResult couponList(SysCoupon coupon) {
        return success(billingService.selectCouponList(coupon));
    }

    /**
     * 新增优惠券模板
     */
    @PostMapping("/coupon")
    public AjaxResult addCoupon(@RequestBody SysCoupon coupon) {
        return toAjax(billingService.insertCoupon(coupon));
    }

    /**
     * 修改优惠券模板
     */
    @PutMapping("/coupon")
    public AjaxResult editCoupon(@RequestBody SysCoupon coupon) {
        return toAjax(billingService.updateCoupon(coupon));
    }

    /**
     * 删除优惠券模板
     */
    @DeleteMapping("/coupon/{couponIds}")
    public AjaxResult removeCoupon(@PathVariable("couponIds") Long[] couponIds) {
        return toAjax(billingService.deleteCouponByIds(couponIds));
    }

    /**
     * 为指定用户发放优惠券
     */
    @PostMapping("/grantCoupon")
    public AjaxResult grantCoupon(@RequestBody Map<String, Object> params) {
        Long userId = Long.valueOf(params.get("userId").toString());
        Long couponId = Long.valueOf(params.get("couponId").toString());
        return toAjax(billingService.grantCoupon(userId, couponId));
    }

    /**
     * 获取结算记录详细信息
     */
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") String id) {
        return success(billingService.selectBillingById(id));
    }

    /**
     * 新增结算记录并返回对象 (带ID)
     */
    @PostMapping
    public AjaxResult add(@RequestBody Billing billing) {
        int rows = billingService.insertBilling(billing);
        return rows > 0 ? AjaxResult.success(billing) : AjaxResult.error();
    }

    /**
     * 获取当前用户的待支付账单
     */
    @GetMapping("/myPending")
    public AjaxResult myPendingBills() {
        Billing billing = new Billing();
        billing.setMemberId(getUserId().toString());
        billing.setStatus("0"); // 待支付
        return success(billingService.selectBillingList(billing));
    }

    /**
     * 移动端直接支付账单 (简化版，仅支持余额支付)
     */
    @PostMapping("/pay/{id}")
    public AjaxResult payBill(@PathVariable("id") String id) {
        try {
            return toAjax(billingService.settle(id, "BALANCE", null, null));
        } catch (Exception e) {
            return error(e.getMessage());
        }
    }

    /**
     * 执行结算 (支持优惠券和多种支付方式)
     */
    @PostMapping("/settle")
    public AjaxResult settle(@RequestBody Map<String, Object> params) {
        String billingId = (String) params.get("id");
        String method = (String) params.get("paymentMethod");
        Long userCouponId = params.get("userCouponId") != null ? Long.valueOf(params.get("userCouponId").toString()) : null;
        List<Map<String, Object>> items = (List<Map<String, Object>>) params.get("items");
        
        try {
            return toAjax(billingService.settle(billingId, method, userCouponId, items));
        } catch (Exception e) {
            return error(e.getMessage());
        }
    }
}
