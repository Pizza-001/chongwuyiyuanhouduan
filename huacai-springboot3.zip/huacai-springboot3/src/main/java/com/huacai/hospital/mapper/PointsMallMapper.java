package com.huacai.hospital.mapper;

import com.huacai.hospital.domain.PointsExchangeRecord;
import com.huacai.hospital.domain.PointsProduct;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.util.List;

@Mapper
public interface PointsMallMapper {
    /**
     * 查询商城商品列表
     */
    public List<PointsProduct> selectPointsProductList(PointsProduct product);

    /**
     * 根据ID查询商品
     */
    public PointsProduct selectPointsProductById(Long id);

    /**
     * 减少商城商品库存
     */
    public int reduceMallStock(@Param("id") Long id, @Param("count") Integer count);

    /**
     * 新增兑换记录
     */
    public int insertExchangeRecord(PointsExchangeRecord record);

    /**
     * 查询用户的兑换记录
     */
    public List<PointsExchangeRecord> selectExchangeRecordList(PointsExchangeRecord record);

    /** 后台管理方法 */
    public int insertPointsProduct(PointsProduct product);
    public int updatePointsProduct(PointsProduct product);
    public int deletePointsProductByIds(Long[] ids);
}
