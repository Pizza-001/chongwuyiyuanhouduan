package com.huacai.hospital.controller;

import com.huacai.system.general.annotation.Anonymous;
import com.huacai.system.general.core.controller.BaseController;
import com.huacai.system.general.core.domain.AjaxResult;
import com.huacai.system.general.core.page.TableDataInfo;
import com.huacai.hospital.domain.PointsProduct;
import com.huacai.hospital.service.PointsMallService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@Tag(name = "积分商城", description = "积分商品查询与兑换")
@RestController
@RequestMapping("/hospital/points-mall")
public class PointsMallController extends BaseController {

    @Autowired
    private PointsMallService pointsMallService;

    /**
     * 获取积分商城商品列表
     */
    @Operation(summary = "获取积分商城商品列表")
    @Anonymous
    @GetMapping("/list")
    public TableDataInfo list(PointsProduct product) {
        startPage();
        List<PointsProduct> list = pointsMallService.selectPointsProductList(product);
        return getDataTable(list);
    }

    /**
     * 兑换商品
     */
    @Operation(summary = "兑换商品")
    @PostMapping("/exchange/{productId}")
    public AjaxResult exchange(@PathVariable Long productId) {
        Long userId = getUserId();
        try {
            boolean success = pointsMallService.exchangeProduct(productId, userId);
            return success ? success("兑换成功") : error("兑换失败");
        } catch (Exception e) {
            return error(e.getMessage());
        }
    }

    @Operation(summary = "获取我的兑换记录")
    @GetMapping("/exchange/list")
    public TableDataInfo exchangeList() {
        Long userId = getUserId();
        startPage();
        return getDataTable(pointsMallService.selectExchangeRecordList(userId));
    }

    /**
     * 获取商品详细信息
     */
    @PreAuthorize("@ss.hasPermi('hospital:points-mall:query')")
    @GetMapping("/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id) {
        return success(pointsMallService.selectPointsProductById(id));
    }

    /**
     * 新增商城商品
     */
    @PreAuthorize("@ss.hasPermi('hospital:points-mall:add')")
    @PostMapping
    public AjaxResult add(@RequestBody PointsProduct product) {
        return toAjax(pointsMallService.insertPointsProduct(product));
    }

    /**
     * 修改商城商品
     */
    @PreAuthorize("@ss.hasPermi('hospital:points-mall:edit')")
    @PutMapping
    public AjaxResult edit(@RequestBody PointsProduct product) {
        return toAjax(pointsMallService.updatePointsProduct(product));
    }

    /**
     * 删除商城商品
     */
    @PreAuthorize("@ss.hasPermi('hospital:points-mall:remove')")
    @DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids) {
        return toAjax(pointsMallService.deletePointsProductByIds(ids));
    }
}
