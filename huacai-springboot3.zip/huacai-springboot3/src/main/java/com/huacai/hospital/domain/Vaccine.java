package com.huacai.hospital.domain;

import com.huacai.system.general.annotation.Excel;
import com.huacai.system.general.core.domain.BaseEntity;
import lombok.*;

/**
 * 疫苗对象 vaccine
 *
 * @author huacai
 * @date 2025-10-27
 */
@EqualsAndHashCode(callSuper = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Vaccine extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 疫苗ID */
    private String vaccineId;

    /** 疫苗名称 */
    @Excel(name = "疫苗名称")
    private String name;

    /** 生产厂家 */
    @Excel(name = "生产厂家")
    private String manufacturer;

    /** 适用对象 */
    @Excel(name = "适用对象")
    private String targetScope;

    /** 价格 */
    @Excel(name = "价格")
    private java.math.BigDecimal price;

    /** 状态（0正常 1下架） */
    @Excel(name = "状态", readConverterExp = "0=正常,1=下架")
    private String status;

    /** 注意事项/禁忌 */
    @Excel(name = "注意事项")
    private String notes;

    /** 详细描述 */
    @Excel(name = "描述")
    private String description;


}
