package com.huacai.hospital.controller;

import java.util.List;
import jakarta.servlet.http.HttpServletResponse;
import com.huacai.system.general.utils.SecurityUtils;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.huacai.hospital.domain.Pet;
import com.huacai.hospital.service.IPetService;
import com.huacai.system.general.core.controller.BaseController;
import com.huacai.system.general.core.domain.AjaxResult;
import com.huacai.system.general.core.page.TableDataInfo;

/**
 * 宠物档案Controller
 */
@RestController
@RequestMapping("/hospital/pet")
public class PetController extends BaseController {
    @Autowired
    private IPetService petService;

    /**
     * 查询宠物档案列表
     */
    @GetMapping("/list")
    public TableDataInfo list(Pet pet) {
        startPage();
        List<Pet> list = petService.selectPetList(pet);
        return getDataTable(list);
    }
    
    /**
     * 移动端查询我的宠物列表
     */
    @GetMapping("/myPets")
    public TableDataInfo myPets(Pet pet) {
        startPage();
        try {
            Long userId = SecurityUtils.getUserId();
            pet.setUserId(userId);
        } catch (Exception e) {
            // Optional handling if no user logged in
        }
        List<Pet> list = petService.selectPetList(pet);
        return getDataTable(list);
    }

    /**
     * 获取宠物档案详细信息
     */
    @GetMapping(value = "/{petId}")
    public AjaxResult getInfo(@PathVariable("petId") String petId) {
        return success(petService.selectPetById(petId));
    }

    /**
     * 新增宠物档案
     */
    @PostMapping
    public AjaxResult add(@RequestBody Pet pet) {
        return toAjax(petService.insertPet(pet));
    }

    /**
     * 小程序端新增我的宠物
     */
    @PostMapping("/myPets")
    public AjaxResult addMyPet(@RequestBody Pet pet) {
        try {
            Long userId = SecurityUtils.getUserId();
            pet.setUserId(userId);
        } catch (Exception e) {}
        return toAjax(petService.insertPet(pet));
    }

    /**
     * 修改宠物档案
     */
    @PutMapping
    public AjaxResult edit(@RequestBody Pet pet) {
        return toAjax(petService.updatePet(pet));
    }
    
    /**
     * 小程序端修改我的宠物
     */
    @PutMapping("/myPets")
    public AjaxResult editMyPet(@RequestBody Pet pet) {
        try {
            Long userId = SecurityUtils.getUserId();
            // Optional identity verification can be added here
            pet.setUserId(userId);
        } catch (Exception e) {}
        return toAjax(petService.updatePet(pet));
    }

    /**
     * 删除宠物档案
     */
    @DeleteMapping("/{petIds}")
    public AjaxResult remove(@PathVariable String[] petIds) {
        return toAjax(petService.deletePetByIds(petIds));
    }
}
