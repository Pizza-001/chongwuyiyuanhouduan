package com.huacai.hospital.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.huacai.system.general.core.domain.BaseEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import java.math.BigDecimal;
import java.util.Date;

/**
 * 宠物医疗记录对象 hospital_medical_record
 */
@EqualsAndHashCode(callSuper = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class MedicalRecord extends BaseEntity
{
    private static final long serialVersionUID = 1L;
    
    /** 宠物姓名 */
    @com.huacai.system.general.annotation.Excel(name = "宠物姓名")
    private String petName;

    /** 医生姓名 */
    @com.huacai.system.general.annotation.Excel(name = "医生姓名")
    private String doctorName;

    /** 记录ID */
    private String recordId;

    /** 宠物ID */
    private String petId;

    /** 医生ID */
    private Long doctorId;

    /** 主观记录 (S) */
    private String subjective;

    /** 客观检查 (O) */
    private String objective;

    /** 诊断评估 (A) */
    private String assessment;

    /** 治疗计划 (P) */
    private String plan;

    /** 就诊体重(kg) */
    private BigDecimal weightAtVisit;

    /** 就诊类型 */
    private String visitType;

    /** 就诊时间 */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date visitTime;
}
