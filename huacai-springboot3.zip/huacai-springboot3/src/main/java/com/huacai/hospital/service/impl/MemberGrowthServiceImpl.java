package com.huacai.hospital.service.impl;

import com.huacai.hospital.domain.SysGrowthRecord;
import com.huacai.hospital.domain.SysMember;
import com.huacai.hospital.mapper.SysGrowthRecordMapper;
import com.huacai.hospital.mapper.SysMemberMapper;
import com.huacai.hospital.service.IMemberGrowthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * 会员成长值Service业务层处理
 */
@Service
public class MemberGrowthServiceImpl implements IMemberGrowthService {
    @Autowired
    private SysMemberMapper memberMapper;
    
    @Autowired
    private SysGrowthRecordMapper growthRecordMapper;

    @Override
    @Transactional
    public void addGrowth(Long userId, Long amount, String type, String remark) {
        if (amount == null || amount <= 0) return;
        
        SysMember member = memberMapper.selectSysMemberByUserId(userId);
        if (member == null) return;

        Long currentGrowth = member.getGrowthValue() != null ? member.getGrowthValue() : 0L;
        Long newGrowth = currentGrowth + amount;
        member.setGrowthValue(newGrowth);

        // 自动升级逻辑 (0青铜 1白银 2黄金 3铂金 4钻石)
        // 对应阈值: 0, 1000, 5000, 15000, 50000
        String newLevel = "0";
        if (newGrowth >= 50000) newLevel = "4";
        else if (newGrowth >= 15000) newLevel = "3";
        else if (newGrowth >= 5000) newLevel = "2";
        else if (newGrowth >= 1000) newLevel = "1";
        member.setLevel(newLevel);

        memberMapper.updateSysMember(member);

        // 增加成长值流水记录
        SysGrowthRecord record = new SysGrowthRecord();
        record.setUserId(userId);
        record.setType(type);
        record.setChangeAmount(amount);
        record.setCurrentGrowth(newGrowth);
        record.setRemark(remark);
        growthRecordMapper.insertGrowthRecord(record);
    }
}
