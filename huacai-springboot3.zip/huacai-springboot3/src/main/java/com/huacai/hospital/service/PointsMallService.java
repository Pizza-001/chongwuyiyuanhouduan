package com.huacai.hospital.service;

import com.huacai.hospital.domain.PointsExchangeRecord;
import com.huacai.hospital.domain.PointsProduct;
import java.util.List;

public interface PointsMallService {
    /**
     * 查询商城商品列表
     */
    public List<PointsProduct> selectPointsProductList(PointsProduct product);

    /**
     * 兑换商品
     * @param productId 商城商品ID
     * @param userId 用户ID
     * @return 兑换结果
     */
    public boolean exchangeProduct(Long productId, Long userId);

    /**
     * 查询兑换记录
     */
    public List<PointsExchangeRecord> selectExchangeRecordList(Long userId);

    /** 后台管理接口 */
    public PointsProduct selectPointsProductById(Long id);
    public int insertPointsProduct(PointsProduct product);
    public int updatePointsProduct(PointsProduct product);
    public int deletePointsProductByIds(Long[] ids);
}
