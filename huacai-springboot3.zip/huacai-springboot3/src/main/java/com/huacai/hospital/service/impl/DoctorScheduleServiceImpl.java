package com.huacai.hospital.service.impl;

import com.huacai.hospital.domain.DoctorSchedule;
import com.huacai.hospital.mapper.DoctorScheduleMapper;
import com.huacai.hospital.service.IDoctorScheduleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class DoctorScheduleServiceImpl implements IDoctorScheduleService {
    @Autowired
    private DoctorScheduleMapper scheduleMapper;

    @Override
    public List<DoctorSchedule> selectDoctorScheduleList(DoctorSchedule schedule) {
        return scheduleMapper.selectDoctorScheduleList(schedule);
    }

    @Override
    public DoctorSchedule selectDoctorScheduleById(Long scheduleId) {
        return scheduleMapper.selectDoctorScheduleById(scheduleId);
    }

    @Override
    public int insertDoctorSchedule(DoctorSchedule schedule) {
        return scheduleMapper.insertDoctorSchedule(schedule);
    }

    @Override
    public int updateDoctorSchedule(DoctorSchedule schedule) {
        return scheduleMapper.updateDoctorSchedule(schedule);
    }

    @Override
    public int deleteDoctorScheduleByIds(Long[] scheduleIds) {
        return scheduleMapper.deleteDoctorScheduleByIds(scheduleIds);
    }
}
