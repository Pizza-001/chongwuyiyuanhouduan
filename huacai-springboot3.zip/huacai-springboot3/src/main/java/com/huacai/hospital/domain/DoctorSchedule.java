package com.huacai.hospital.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.huacai.system.general.core.domain.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import java.util.Date;

/**
 * 医生排班对象 doctor_schedule
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class DoctorSchedule extends BaseEntity {
    private static final long serialVersionUID = 1L;

    private Long scheduleId;
    private String doctorId;
    
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date workDate;
    
    private String period; // 上午/下午/全天
    private Integer maxCount;
    private Integer usedCount;
    private String status;

    // 辅助字段
    private String doctorName;
}
