package com.huacai.hospital.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.huacai.system.general.core.domain.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import java.math.BigDecimal;
import java.util.Date;

/**
 * 优惠券对象 sys_coupon
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class SysCoupon extends BaseEntity {
    private static final long serialVersionUID = 1L;

    private Long couponId;
    private String title;
    private String type; // CASH, PERCENT
    private BigDecimal amount;
    private BigDecimal minSpend;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date validFrom;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date validTo;

    private String status;
}
