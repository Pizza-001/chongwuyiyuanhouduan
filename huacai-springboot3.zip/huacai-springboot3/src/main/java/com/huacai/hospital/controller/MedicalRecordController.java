package com.huacai.hospital.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.huacai.system.general.core.controller.BaseController;
import com.huacai.system.general.core.domain.AjaxResult;
import com.huacai.hospital.domain.MedicalRecord;
import com.huacai.hospital.service.IMedicalRecordService;
import com.huacai.system.general.core.page.TableDataInfo;

/**
 * 宠物医疗记录Controller
 */
@RestController
@RequestMapping("/hospital/record")
public class MedicalRecordController extends BaseController
{
    @Autowired
    private IMedicalRecordService medicalRecordService;

    /**
     * 查询我的就诊历史
     */
    @GetMapping("/myRecord")
    public AjaxResult myRecord()
    {
        MedicalRecord medicalRecord = new MedicalRecord();
        medicalRecord.getParams().put("userId", getUserId());
        List<MedicalRecord> list = medicalRecordService.selectMedicalRecordList(medicalRecord);
        return AjaxResult.success(list);
    }

    /**
     * 查询宠物医疗记录列表
     */
    @GetMapping("/list")
    public TableDataInfo list(MedicalRecord medicalRecord)
    {
        startPage();
        List<MedicalRecord> list = medicalRecordService.selectMedicalRecordList(medicalRecord);
        return getDataTable(list);
    }

    /**
     * 获取宠物医疗记录详细信息
     */
    @GetMapping(value = "/{recordId}")
    public AjaxResult getInfo(@PathVariable("recordId") String recordId)
    {
        return AjaxResult.success(medicalRecordService.selectMedicalRecordById(recordId));
    }

    /**
     * 新增宠物医疗记录
     */
    @PostMapping
    public AjaxResult add(@RequestBody MedicalRecord medicalRecord)
    {
        return toAjax(medicalRecordService.insertMedicalRecord(medicalRecord));
    }

    /**
     * 修改宠物医疗记录
     */
    @PutMapping
    public AjaxResult edit(@RequestBody MedicalRecord medicalRecord)
    {
        return toAjax(medicalRecordService.updateMedicalRecord(medicalRecord));
    }

    /**
     * 删除宠物医疗记录
     */
	@DeleteMapping("/{recordIds}")
    public AjaxResult remove(@PathVariable String[] recordIds)
    {
        return toAjax(medicalRecordService.deleteMedicalRecordByIds(recordIds));
    }
}
