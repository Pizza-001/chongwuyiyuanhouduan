package com.huacai.hospital.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.huacai.system.general.core.controller.BaseController;
import com.huacai.hospital.domain.Medicine;
import com.huacai.hospital.service.IMedicineService;
import com.huacai.system.general.core.domain.AjaxResult;
import com.huacai.system.general.core.page.TableDataInfo;

@RestController
@RequestMapping("/hospital/medicine")
public class MedicineController extends BaseController
{
    @Autowired
    private IMedicineService medicineService;

    /**
     * 获取所有药品分类 (移到最上方避免路径匹配冲突)
     */
    @GetMapping("/categories")
    public AjaxResult getCategories()
    {
        return AjaxResult.success(medicineService.selectMedicineCategories());
    }

    /**
     * 查询药品列表
     */
    @GetMapping("/list")
    public TableDataInfo list(Medicine medicine)
    {
        startPage();
        List<Medicine> list = medicineService.selectMedicineList(medicine);
        return getDataTable(list);
    }

    /**
     * 获取药品详情
     */
    @GetMapping("/{medicineId}")
    public AjaxResult getInfo(@PathVariable("medicineId") Long medicineId)
    {
        return AjaxResult.success(medicineService.selectMedicineByMedicineId(medicineId));
    }

    /**
     * 新增药品
     */
    @PostMapping
    public AjaxResult add(@RequestBody Medicine medicine)
    {
        return toAjax(medicineService.insertMedicine(medicine));
    }

    /**
     * 修改药品
     */
    @PutMapping
    public AjaxResult edit(@RequestBody Medicine medicine)
    {
        return toAjax(medicineService.updateMedicine(medicine));
    }

    /**
     * 删除药品
     */
    @DeleteMapping("/{medicineIds}")
    public AjaxResult remove(@PathVariable Long[] medicineIds)
    {
        return toAjax(medicineService.deleteMedicineByMedicineIds(medicineIds));
    }
}
