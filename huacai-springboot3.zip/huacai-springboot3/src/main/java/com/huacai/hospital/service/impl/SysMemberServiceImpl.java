package com.huacai.hospital.service.impl;

import com.huacai.system.general.utils.DateUtils;
import com.huacai.system.general.utils.uuid.IdUtils;
import com.huacai.hospital.domain.SysMember;
import com.huacai.hospital.domain.TransactionRecord;
import com.huacai.hospital.mapper.SysMemberMapper;
import com.huacai.hospital.mapper.TransactionRecordMapper;
import com.huacai.hospital.service.ISysMemberService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

/**
 * 会员档案Service业务层处理
 */
@Service
public class SysMemberServiceImpl implements ISysMemberService {
    @Autowired
    private SysMemberMapper memberMapper;
    
    @Autowired
    private TransactionRecordMapper recordMapper;

    @Override
    public SysMember selectSysMemberById(Long memberId) {
        return memberMapper.selectSysMemberById(memberId);
    }
    
    @Override
    public SysMember selectSysMemberByUserId(Long userId) {
        SysMember member = memberMapper.selectSysMemberByUserId(userId);
        if (member == null) {
            // 如果用户还没有资产表，就自动初始化一个
            member = new SysMember();
            member.setUserId(userId);
            member.setLevel("0");
            member.setBalance(BigDecimal.ZERO);
            member.setPoints(0L);
            member.setTotalPoints(0L);
            member.setCreateTime(DateUtils.getNowDate());
            memberMapper.insertSysMember(member);
        }
        return member;
    }

    @Override
    public List<SysMember> selectSysMemberList(SysMember sysMember) {
        return memberMapper.selectSysMemberList(sysMember);
    }

    @Override
    public int insertSysMember(SysMember sysMember) {
        sysMember.setCreateTime(DateUtils.getNowDate());
        return memberMapper.insertSysMember(sysMember);
    }

    @Override
    public int updateSysMember(SysMember sysMember) {
        sysMember.setUpdateTime(DateUtils.getNowDate());
        return memberMapper.updateSysMember(sysMember);
    }

    @Override
    public int deleteSysMemberById(Long memberId) {
        return memberMapper.deleteSysMemberById(memberId);
    }
    
    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean recharge(Long userId, BigDecimal amount, String paymentMethod) {
        if (amount.compareTo(BigDecimal.ZERO) <= 0) {
            throw new RuntimeException("充值金额必须大于0");
        }
        
        // 计算额外赠送金额
        BigDecimal bonus = BigDecimal.ZERO;
        double amt = amount.doubleValue();
        if (amt >= 1000) bonus = new BigDecimal("120");
        else if (amt >= 500) bonus = new BigDecimal("50");
        else if (amt >= 200) bonus = new BigDecimal("15");
        else if (amt >= 100) bonus = new BigDecimal("5");
        
        BigDecimal totalArrival = amount.add(bonus);
        
        SysMember member = selectSysMemberByUserId(userId);
        member.setBalance(member.getBalance().add(totalArrival));
        memberMapper.updateSysMember(member);
        
        // 记录流水
        TransactionRecord record = new TransactionRecord();
        record.setId(IdUtils.fastSimpleUUID());
        record.setUserId(userId);
        record.setType("RECHARGE");
        record.setAmount(totalArrival);
        record.setPaymentMethod(paymentMethod);
        record.setPointsEarned(0L);
        record.setCreateTime(DateUtils.getNowDate());
        record.setRemark("充值:" + amount + ", 赠送:" + bonus);
        recordMapper.insertTransactionRecord(record);
        
        return true;
    }
    
    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean consume(Long userId, BigDecimal amount, String remark) {
        if (amount.compareTo(BigDecimal.ZERO) < 0) {
            throw new RuntimeException("金额异常");
        }
        // $0 免费订单直接通过
        if (amount.compareTo(BigDecimal.ZERO) == 0) {
            return true;
        }
        
        SysMember member = selectSysMemberByUserId(userId);
        if (member.getBalance().compareTo(amount) < 0) {
            throw new RuntimeException("余额不足，请先充值");
        }
        
        // 扣款计算积分 (由于1元=1积分)
        long earned = amount.longValue();
        member.setBalance(member.getBalance().subtract(amount));
        member.setPoints(member.getPoints() + earned);
        member.setTotalPoints(member.getTotalPoints() + earned);
        
        // 判断等级提升逻辑: 100白银 500黄金 1000钻石
        long tp = member.getTotalPoints();
        if(tp >= 1000) member.setLevel("3");
        else if(tp >= 500) member.setLevel("2");
        else if(tp >= 100) member.setLevel("1");
        
        memberMapper.updateSysMember(member);
        
        // 记录流水
        TransactionRecord record = new TransactionRecord();
        record.setId(IdUtils.fastSimpleUUID());
        record.setUserId(userId);
        record.setType("CONSUME");
        record.setAmount(amount);
        record.setPaymentMethod("BALANCE");
        record.setPointsEarned(earned);
        record.setCreateTime(DateUtils.getNowDate());
        recordMapper.insertTransactionRecord(record);
        
        return true;
    }
}
