package com.huacai.hospital.mapper;

import com.huacai.hospital.domain.SysMember;
import org.apache.ibatis.annotations.Mapper;
import java.util.List;

/**
 * 会员档案Mapper接口
 */
@Mapper
public interface SysMemberMapper {
    /**
     * 查询会员档案
     * @param memberId 会员ID
     * @return 会员档案
     */
    public SysMember selectSysMemberById(Long memberId);
    
    /**
     * 根据用户ID查询会员档案
     * @param userId 用户ID
     * @return 会员档案
     */
    public SysMember selectSysMemberByUserId(Long userId);

    /**
     * 查询会员档案列表
     * @param sysMember 会员档案
     * @return 会员档案集合
     */
    public List<SysMember> selectSysMemberList(SysMember sysMember);

    /**
     * 新增会员档案
     * @param sysMember 会员档案
     * @return 结果
     */
    public int insertSysMember(SysMember sysMember);

    /**
     * 修改会员档案
     * @param sysMember 会员档案
     * @return 结果
     */
    public int updateSysMember(SysMember sysMember);

    /**
     * 删除会员档案
     * @param memberId 会员ID
     * @return 结果
     */
    public int deleteSysMemberById(Long memberId);
}
