package com.huacai.hospital.controller;

import java.util.List;

import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.huacai.system.general.core.controller.BaseController;
import com.huacai.system.general.core.domain.AjaxResult;

import java.io.InputStream;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.multipart.MultipartFile;
import com.huacai.hospital.domain.Doctor;
import com.huacai.hospital.service.IDoctorService;
import com.huacai.system.general.utils.poi.ExcelUtil;
import com.huacai.system.general.core.page.TableDataInfo;

/**
 * 医生Controller
 *
 * @author huacai
 * @date 2025-10-27
 */
@Tag(name = "14-医生管理", description = "医生增删改查、导入导出等")
@RestController
@RequestMapping("/hospital/doctor")
public class DoctorController extends BaseController {
    @Autowired
    private IDoctorService doctorService;

    @Operation(summary = "查询医生列表")
    @GetMapping("/list")
    public TableDataInfo list(Doctor doctor) {
        startPage();
        List<Doctor> list = doctorService.selectDoctorList(doctor);
        return getDataTable(list);
    }

    @Operation(summary = "导出医生列表")
    @PostMapping("/export")
    public void export(HttpServletResponse response, Doctor doctor) {
        List<Doctor> list = doctorService.selectDoctorList(doctor);
        ExcelUtil<Doctor> util = new ExcelUtil<Doctor>(Doctor. class);
        util.exportExcel(response, list, "医生数据");
    }

    @Operation(summary = "下载导入模板")
    @PostMapping("/importTemplate")
    public void importTemplate(HttpServletResponse response) {
        ExcelUtil<Doctor> util = new ExcelUtil<Doctor>(Doctor. class);
        util.importTemplateExcel(response, "医生数据");
    }

    @Operation(summary = "导入医生数据")
    @PostMapping("/importData")
    public AjaxResult importData(MultipartFile file) throws Exception {
        ExcelUtil<Doctor> util = new ExcelUtil<Doctor>(Doctor. class);
        InputStream inputStream = file.getInputStream();
        List<Doctor> list = util.importExcel(inputStream);
        inputStream.close();
        int count = doctorService.batchInsertDoctor(list);
        return AjaxResult.success("导入成功" + count + "条信息！");
    }

    @Operation(summary = "获取医生详细信息")
    @GetMapping(value = "/{doctorId}")
    public AjaxResult getInfo(@PathVariable("doctorId") String doctorId) {
        return success(doctorService.selectDoctorByDoctorId(doctorId));
    }

    @Operation(summary = "新增医生")
    @PostMapping
    public AjaxResult add(@RequestBody Doctor doctor) {
        return toAjax(doctorService.insertDoctor(doctor));
    }

    @Operation(summary = "修改医生")
    @PutMapping
    public AjaxResult edit(@RequestBody Doctor doctor) {
        return toAjax(doctorService.updateDoctor(doctor));
    }

    @Operation(summary = "更新医生状态")
    @PatchMapping("/{doctorId}")
    public AjaxResult updateStatus(@PathVariable String doctorId, @RequestBody Doctor doctor) {
        doctor.setDoctorId(doctorId);
        return toAjax(doctorService.updateDoctor(doctor));
    }

    @Operation(summary = "删除医生")
    @DeleteMapping("/{doctorIds}")
    public AjaxResult remove(@PathVariable String[] doctorIds) {
        return toAjax(doctorService.deleteDoctorByDoctorIds(doctorIds));
    }
}
