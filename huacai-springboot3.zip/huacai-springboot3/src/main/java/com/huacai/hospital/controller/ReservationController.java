package com.huacai.hospital.controller;

import java.util.List;
import java.util.UUID;
import java.math.BigDecimal;
import java.io.InputStream;
import com.huacai.system.general.utils.SecurityUtils;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

import com.huacai.system.general.core.controller.BaseController;
import com.huacai.system.general.core.domain.AjaxResult;
import com.huacai.system.general.core.page.TableDataInfo;
import com.huacai.system.general.utils.poi.ExcelUtil;

import com.huacai.hospital.domain.Reservation;
import com.huacai.hospital.domain.Billing;
import com.huacai.hospital.domain.Vaccine;
import com.huacai.hospital.domain.Doctor;
import com.huacai.hospital.service.IReservationService;
import com.huacai.hospital.service.IBillingService;
import com.huacai.hospital.service.IVaccineService;
import com.huacai.hospital.service.IDoctorService;
import com.huacai.hospital.service.ISysMemberService;

/**
 * 预约Controller
 *
 * @author huacai
 * @date 2025-10-27
 */
@Tag(name = "16-预约管理", description = "预约增删改查、导入导出等")
@RestController
@RequestMapping("/hospital/reservation")
public class ReservationController extends BaseController {
    @Autowired
    private IReservationService reservationService;

    @Autowired
    private IBillingService billingService;

    @Autowired
    private IVaccineService vaccineService;

    @Autowired
    private IDoctorService doctorService;

    @Autowired
    private ISysMemberService memberService;

    @Operation(summary = "查询预约列表")
    @GetMapping("/list")
    public TableDataInfo list(Reservation reservation) {
        startPage();
        List<Reservation> list = reservationService.selectReservationList(reservation);
        return getDataTable(list);
    }

    @Operation(summary = "查询个人的所有预约列表")
    @GetMapping("/selectMyReservationList")
    public AjaxResult selectMyReservationList() {
        Reservation reservation = new Reservation();
        reservation.setUserId(getUserId());
        List<Reservation> list = reservationService.selectReservationList(reservation);
        return success(list);
    }

    @Operation(summary = "导出预约列表")
    @PostMapping("/export")
    public void export(HttpServletResponse response, Reservation reservation) {
        List<Reservation> list = reservationService.selectReservationList(reservation);
        ExcelUtil<Reservation> util = new ExcelUtil<>(Reservation.class);
        util.exportExcel(response, list, "预约数据");
    }

    @Operation(summary = "下载导入模板")
    @PostMapping("/importTemplate")
    public void importTemplate(HttpServletResponse response) {
        ExcelUtil<Reservation> util = new ExcelUtil<>(Reservation.class);
        util.importTemplateExcel(response, "预约数据");
    }

    @Operation(summary = "导入预约数据")
    @PostMapping("/importData")
    public AjaxResult importData(MultipartFile file) throws Exception {
        ExcelUtil<Reservation> util = new ExcelUtil<>(Reservation.class);
        InputStream inputStream = file.getInputStream();
        List<Reservation> list = util.importExcel(inputStream);
        inputStream.close();
        int count = reservationService.batchInsertReservation(list);
        return AjaxResult.success("导入成功" + count + "条信息！");
    }

    @Operation(summary = "获取预约详细信息")
    @GetMapping(value = "/{reservationId}")
    public AjaxResult getInfo(@PathVariable("reservationId") String reservationId) {
        return success(reservationService.selectReservationByReservationId(reservationId));
    }

    @Operation(summary = "新增预约 (生成待缴账单)")
    @PostMapping
    public AjaxResult add(@RequestBody Reservation reservation) {
        // 获取当前用户
        Long currentUserId = SecurityUtils.getUserId();
        reservation.setUserId(currentUserId);
        
        // 生成唯一预约ID
        String rId = "R" + System.currentTimeMillis();
        reservation.setReservationId(rId);
        
        // 自动计算费用
        BigDecimal cost = BigDecimal.ZERO;
        String remark = "普通挂号";
        
        if ("疫苗预约".equals(reservation.getType()) && reservation.getVaccineId() != null) {
            Vaccine v = vaccineService.selectVaccineByVaccineId(reservation.getVaccineId());
            if (v != null && v.getPrice() != null) {
                cost = v.getPrice();
                remark = "预约疫苗: " + v.getName();
            }
        } else {
            // 普通预约，获取医生的挂号费
            Doctor doc = doctorService.selectDoctorByDoctorId(reservation.getDoctorId());
            if (doc != null && doc.getFee() != null) {
                cost = BigDecimal.valueOf(doc.getFee());
                remark = "专家门诊: " + doc.getName();
            } else {
                cost = new BigDecimal("50.00");
                remark = "专家门诊 (标准费率)";
            }
        }
        
        // 创建待结算单据
        Billing billing = new Billing();
        billing.setId(UUID.randomUUID().toString());
        billing.setOrderNo("B" + System.currentTimeMillis());
        billing.setMemberId(currentUserId.toString());
        billing.setPetId(reservation.getPetId());
        billing.setTotalAmount(cost);
        billing.setPayAmount(cost);
        billing.setSourceId(rId); // 关联预约单号
        billing.setBusinessType(reservation.getType().equals("疫苗预约") ? "VACCINE" : "CLINIC");
        billing.setStatus("0"); // 待结算
        billing.setRemark(remark + " [移动端预约生成]");
        billingService.insertBilling(billing);
        
        return toAjax(reservationService.insertReservation(reservation));
    }

    @Operation(summary = "修改预约")
    @PutMapping
    public AjaxResult edit(@RequestBody Reservation reservation) {
        return toAjax(reservationService.updateReservation(reservation));
    }

    @Operation(summary = "删除预约")
    @DeleteMapping("/{reservationIds}")
    public AjaxResult remove(@PathVariable String[] reservationIds) {
        return toAjax(reservationService.deleteReservationByReservationIds(reservationIds));
    }
}
