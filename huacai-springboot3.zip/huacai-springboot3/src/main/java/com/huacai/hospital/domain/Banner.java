package com.huacai.hospital.domain;

import com.huacai.system.general.annotation.Excel;
import com.huacai.system.general.core.domain.BaseEntity;
import lombok.*;

/**
 * 轮播图对象 banner
 *
 * @author huacai
 * @date 2025-10-26
 */
@EqualsAndHashCode(callSuper = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Banner extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 轮播图ID */
    private String bannerId;

    /** 标题 */
    private String title;

    /** 图片 */
    @Excel(name = "图片")
    private String image;

    /** 链接地址 */
    private String linkUrl;

    /** 排序 */
    @Excel(name = "排序")
    private Long sort;

    /** 状态（0显示 1隐藏） */
    private String status;


}
