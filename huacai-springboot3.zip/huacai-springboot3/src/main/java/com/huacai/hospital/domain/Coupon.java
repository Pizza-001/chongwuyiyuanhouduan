package com.huacai.hospital.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.huacai.system.general.annotation.Excel;
import com.huacai.system.general.core.domain.BaseEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.Date;

/**
 * 优惠券定义 coupon
 */
@EqualsAndHashCode(callSuper = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Coupon extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /** 优惠券ID */
    private Long id;

    /** 名称 */
    @Excel(name = "名称")
    private String name;

    /** 类型 (DISCOUNT 折扣券, FULL_REDUCTION 满减券, CASH 现金抵扣券) */
    @Excel(name = "类型")
    private String type;

    /** 面值/折扣率 */
    @Excel(name = "面值")
    private BigDecimal value;

    /** 使用门槛(满多少可用) */
    @Excel(name = "使用门槛")
    private BigDecimal minAmount;

    /** 发放数量限制 */
    private Integer totalLimit;

    /** 已领取数量 */
    private Integer usedCount;

    /** 过期时间 */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Excel(name = "过期时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
    private Date expireTime;
}
