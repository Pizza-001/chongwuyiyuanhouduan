package com.huacai.hospital.service;

import com.huacai.hospital.domain.Billing;
import com.huacai.hospital.domain.SysCoupon;
import com.huacai.hospital.domain.SysUserCoupon;
import java.util.List;
import java.util.Map;

/**
 * 收银结算Service接口
 */
public interface IBillingService {
    public Billing selectBillingById(String id);
    public List<Billing> selectBillingList(Billing billing);
    public int insertBilling(Billing billing);
    public int updateBilling(Billing billing);
    public int deleteBillingByIds(String[] ids);

    /**
     * 执行结算
     * @param billingId 账单ID
     * @param paymentMethod 支付方式
     * @param userCouponId 优惠券ID
     * @param items 商品列表(用于扣减库存)
     * @return 结果
     */
    public int settle(String billingId, String paymentMethod, Long userCouponId, List<Map<String, Object>> items);

    public List<SysUserCoupon> selectMemberCoupons(Long userId);

    public List<SysCoupon> selectCouponList(SysCoupon coupon);

    public int insertCoupon(SysCoupon coupon);

    public int updateCoupon(SysCoupon coupon);

    public int deleteCouponByIds(Long[] couponIds);

    public int grantCoupon(Long userId, Long couponId);

    /** 财务数据统计 */
    public java.math.BigDecimal selectTotalRevenue();
    public java.math.BigDecimal selectTodayRevenue();
}
