package com.huacai.hospital.domain;

import com.huacai.system.general.core.domain.BaseEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * 会员成长值流水对象 sys_growth_record
 */
@EqualsAndHashCode(callSuper = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
public class SysGrowthRecord extends BaseEntity {
    private static final long serialVersionUID = 1L;

    /** 记录ID */
    private Long id;

    /** 用户ID */
    private Long userId;

    /** 变动类型 (CONSUMPTION, TASK, ADJUSTMENT) */
    private String type;

    /** 变动值 */
    private Long changeAmount;

    /** 变动后成长值 */
    private Long currentGrowth;

    /** 备注 */
    private String remark;
}
