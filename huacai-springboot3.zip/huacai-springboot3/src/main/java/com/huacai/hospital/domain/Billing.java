package com.huacai.hospital.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.huacai.system.general.core.domain.BaseEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import java.math.BigDecimal;
import java.util.Date;

/**
 * 收银结算对象 hospital_billing
 */
@EqualsAndHashCode(callSuper = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Billing extends BaseEntity {
    private static final long serialVersionUID = 1L;

    /** ID */
    private String id;

    /** 订单流水号 */
    private String orderNo;

    /** 宠物ID */
    private String petId;

    /** 会员/用户ID */
    private String memberId;

    /** 业务类型(VACCINE, CLINIC, MEDICINE, GENERAL) */
    private String businessType;

    /** 来源业务ID */
    private String sourceId;

    /** 总金额 */
    private BigDecimal totalAmount;

    /** 优惠金额 */
    private BigDecimal discountAmount;

    /** 实付金额 */
    private BigDecimal payAmount;

    /** 支付状态(0待结算, 1已结算, 2已取消) */
    private String status;

    /** 支付方式 */
    private String paymentMethod;

    /** 支付时间 */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date paymentTime;
}
