package com.huacai.hospital.domain;

import com.huacai.system.general.annotation.Excel;
import com.huacai.system.general.core.domain.BaseEntity;
import lombok.*;

/**
 * 养宠知识对象 knowledge
 *
 * @author huacai
 * @date 2025-10-29
 */
@EqualsAndHashCode(callSuper = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Knowledge extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 养宠知识ID */
    private String knowledgeId;

    /** 标题 */
    @Excel(name = "标题")
    private String title;

    /** 分类 */
    @Excel(name = "分类")
    private String category;

    /** 内容贡献者 */
    @Excel(name = "内容贡献者")
    private String author;

    /** 传播热度 (移动端浏览量) */
    @Excel(name = "传播热度")
    private Integer views;

    /** 封面图 */
    @Excel(name = "封面图")
    private String coverImage;

    /** 状态 (0发布 1下架) */
    @Excel(name = "状态")
    private String status;

    /** 内容 */
    @Excel(name = "内容")
    private String content;

    /** 视频路径 */
    @Excel(name = "视频路径")
    private String videoUrl;

}
